/* KISMET — Lashio → Yangon: freight by Kg %, customer groups, order & group editing */
(function () {
  if (window.__lyLoaded) return; window.__lyLoaded = true;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toast = (m) => { try { if (typeof showToast === 'function') showToast(m); } catch (e) {} };
  const num = (v) => parseFloat(v) || 0;
  const fmt = (n) => Math.round(n).toLocaleString();
  const NONAME = '(နာမည်မရှိ)';
  const PAL = ['#8ecff5', '#ffb27a', '#7fcf8e', '#c08bf5', '#7a7fe0', '#e4e68f', '#9be58a', '#8a8a8e', '#ef6b6b', '#f5a3c7'];
  const FAI = { Air: 'fa-plane', Land: 'fa-truck-fast', Post: 'fa-envelope' };
  const GL = { Air: 'လေယာဉ်', Land: 'ကားဂိတ်', Post: 'စာတိုက်' };

  const routeItems = () => { try { return Object.values(allRouteRecords).reduce((a, l) => a.concat(Array.isArray(l) ? l : []), []); } catch (e) { return []; } };
  const gates = () => { try { return gateShipments; } catch (e) { return []; } };
  const pool = () => { try { return (allRouteRecords[ROUTE_KEY] || []).filter(i => i && i.arrived); } catch (e) { return []; } };           // arrived at Lashio, not yet loaded
  const buyerOf = (i) => (i.buyer || '').trim() || NONAME;
  function groupItems(items, feeKey) {
    const m = new Map();
    items.forEach(i => { const k = buyerOf(i); if (!m.has(k)) m.set(k, { name: k, items: [], kg: 0, fee: 0 }); const g = m.get(k); g.items.push(i); g.kg += num(i.kg); g.fee += feeKey ? num(i[feeKey]) : 0; });
    return [...m.values()].sort((a, b) => b.kg - a.kg || a.name.localeCompare(b.name));
  }
  function persist() { try { saveToLocalStorage(); renderAll(); if (typeof renderGateLists === 'function') renderGateLists(); } catch (e) {} sig = ''; renderLY(); try { window.ktRerender && window.ktRerender(); } catch (e) {} }
  function gateOf(id) { return gates().find(g => g.id === id); }
  function gateOfItem(id) { return gates().find(g => (g.items || []).some(i => i.id === id)); }
  function realloc(g) { try { if (g && typeof gRecalc === 'function') gRecalc(g); } catch (e) {} }

  /* ================= 1. Kg % page : switch + Lashio–Yangon view ================= */
  let mode = 'LY', sel = '__pool', openG = new Set(), sig = '';
  try { mode = localStorage.getItem('kismet_kgpage_mode') || 'LY'; } catch (e) {}
  const page = () => $('page-4');

  function ensureShell() {
    const p = page(); if (!p) return false;
    if (!$('lyMode')) {
      const bar = document.createElement('div'); bar.id = 'lyMode'; bar.className = 'ly-mode';
      bar.innerHTML = `<button type="button" data-m="CL">တရုတ် → လားရှိုး</button><button type="button" data-m="LY">လားရှိုး → ရန်ကုန်</button>`;
      bar.addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; mode = b.dataset.m; try { localStorage.setItem('kismet_kgpage_mode', mode); } catch (er) {} sig = ''; applyMode(); renderLY(); });
      const box = document.createElement('div'); box.id = 'ly4'; box.className = 'ly';
      p.insertBefore(bar, p.children[1] || null); p.insertBefore(box, bar.nextSibling);
      box.addEventListener('click', onClick); box.addEventListener('change', onChange);
    }
    return true;
  }
  function applyMode() {
    const p = page(); if (!p) return;
    [...p.children].forEach((c, idx) => { if (idx === 0 || c.id === 'lyMode' || c.id === 'ly4') return; c.style.display = mode === 'LY' ? 'none' : ''; });
    $('ly4').style.display = mode === 'LY' ? '' : 'none';
    $('lyMode').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.m === mode));
    const h = p.querySelector('h2 span:last-child'); if (h) h.textContent = mode === 'LY' ? 'Kg အလိုက် % နှင့် တန်ဆာခ — လားရှိုး → ရန်ကုန်' : 'Kg အလိုက် % နှင့် တန်ဆာခ — တရုတ် → လားရှိုး';
    const b = $('kgRouteItemCount'); if (b) b.style.display = mode === 'LY' ? 'none' : '';
  }

  function donutSVG(groups, total) {
    let s = '<circle cx="21" cy="21" r="15.9155" fill="transparent" stroke="#1c1c1e" stroke-width="5"/>', cum = 0;
    const n = groups.length;
    groups.forEach((g, i) => {
      const pct = total > 0 ? g.kg / total * 100 : 100 / n; if (pct <= 0) return;
      const only = n === 1, gap = only ? 0 : 2, capw = only ? 0 : 5, L = only ? 100 : Math.max(0.01, pct - gap - capw), st = cum + (only ? 0 : (gap + capw) / 2);
      s += `<circle cx="21" cy="21" r="15.9155" fill="transparent" stroke="${PAL[i % PAL.length]}" stroke-width="5" ${only ? '' : 'stroke-linecap="round"'} stroke-dasharray="${L} ${100 - L}" stroke-dashoffset="${100 - st}"/>`;
      cum += pct;
    });
    return s;
  }

  function renderLY() {
    if (!ensureShell()) return; applyMode(); if (mode !== 'LY') return;
    const G = gates(), P = pool();
    if (sel !== '__pool' && !gateOf(sel)) sel = '__pool';
    const isPool = sel === '__pool', g = isPool ? null : gateOf(sel);
    const items = isPool ? P : (g.items || []);
    const kgTot = items.reduce((a, i) => a + num(i.kg), 0);
    const feeKey = isPool ? null : 'gateFee';
    const groups = groupItems(items, feeKey);
    const freight = isPool ? 0 : num(g.freight);
    const chips = `<button type="button" class="ly-chip${isPool ? ' on' : ''}" data-sel="__pool"><i class="fa-solid fa-box-open"></i> လားရှိုးရောက် <b>${P.length}</b></button>` +
      G.map(x => `<button type="button" class="ly-chip${sel === x.id ? ' on' : ''}" data-sel="${esc(x.id)}"><i class="fa-solid ${FAI[x.transport] || FAI.Land}"></i> ${esc(x.gate)} <b>${(x.items || []).length}</b></button>`).join('');
    const sum = `<div class="ly-sum">
      <div><span>စုစုပေါင်း Kg</span><b>${kgTot.toFixed(2)} Kg</b></div>
      <div><span>${isPool ? 'တန်ဆာခ' : 'လားရှိုး → ရန်ကုန် တန်ဆာခ (ကျပ်)'}</span>${isPool ? '<b class="mut">ဂိတ်တင်ပြီးမှ ထည့်ပါ</b>' : `<input id="lyFreight" type="number" inputmode="numeric" min="0" step="1" value="${freight || ''}" placeholder="0">`}</div>
    </div>${!isPool && freight > 0 && kgTot > 0 ? `<div class="ly-rate">Kg တစ်ခုလျှင် ≈ ${fmt(freight / kgTot)} Ks • Kg % အလိုက် ခွဲတွက်ပြီး</div>` : ''}`;
    const donut = groups.length ? `<div class="ly-donut"><div class="ly-ring"><svg viewBox="0 0 42 42" style="transform:rotate(-90deg)">${donutSVG(groups, kgTot)}</svg>
      <div class="ly-center"><b>${kgTot.toFixed(2)} Kg</b><span>${isPool ? items.length + ' မျိုး' : fmt(freight) + ' Ks'}</span></div></div>
      <div class="ly-legend">${groups.map((x, i) => `<div><span><i style="background:${PAL[i % PAL.length]}"></i>${esc(x.name)}</span><b>${(kgTot > 0 ? x.kg / kgTot * 100 : 100 / groups.length).toFixed(1)}%</b></div>`).join('')}</div></div>` : `<div class="ly-empty">${isPool ? 'လားရှိုးရောက်ပြီး ဂိတ်မတင်ရသေးတဲ့ ပစ္စည်း မရှိသေးပါ' : 'ဒီစာရင်းထဲ ပစ္စည်း မရှိပါ'}</div>`;
    const gl = groups.map((x, i) => {
      const pct = kgTot > 0 ? x.kg / kgTot * 100 : 100 / groups.length, open = openG.has(sel + '|' + x.name) || groups.length === 1;
      return `<div class="ly-g"><div class="ly-gh" data-tg="${esc(x.name)}"><i class="ly-dot" style="background:${PAL[i % PAL.length]}"></i>
        <div class="ly-gm"><div class="ly-gn">${esc(x.name)}</div><div class="ly-gs">${x.items.length} order • ${x.kg.toFixed(2)} Kg • ${pct.toFixed(1)}%</div></div>
        ${isPool ? '' : `<b class="ly-fee">${fmt(x.fee)} Ks</b>`}
        <button type="button" class="ly-ib" data-ev="${esc(x.name)}" title="E-Voucher ဘောင်ချာ"><i class="fa-solid fa-receipt"></i></button>
        <button type="button" class="ly-ib" data-eg="${esc(x.name)}" title="Group ပြင်ရန်"><i class="fa-solid fa-pen"></i></button><i class="fa-solid fa-chevron-${open ? 'up' : 'down'} ly-chev"></i></div>
        ${open ? `<div class="ly-gb">${x.items.map(it => `<div class="ly-o"><div class="ly-om"><div class="ly-on">${esc(it.name)} <span>x${esc(it.qty || 1)}</span></div><div class="ly-os">${num(it.kg)} Kg${it.note ? ' • ' + esc(it.note) : ''}</div></div>
          ${isPool ? '' : `<b class="ly-fee">${fmt(num(it.gateFee))} Ks</b>`}<button type="button" class="ly-ib" data-eo="${esc(it.id)}" title="Order ပြင်ရန်"><i class="fa-solid fa-pen"></i></button></div>`).join('')}</div>` : ''}</div>`;
    }).join('');
    const act = isPool ? `<button type="button" class="ly-act" data-act="send"><i class="fa-solid fa-truck-ramp-box"></i>&nbsp; ကား / လေယာဉ် / စာတိုက် ဂိတ်တင်မည်</button>`
      : `<div class="kt-acts" style="margin-top:12px"><button type="button" class="a1" data-act="gv"><i class="fa-solid fa-receipt"></i> ဘယ်သူ ဘယ်လောက်</button><button type="button" class="a2" data-act="gs"><i class="fa-solid fa-image"></i> Gallery သိမ်းမည်</button></div><button type="button" class="ly-act" data-act="gate" style="background:#18181b;color:#a1a1aa"><i class="fa-solid fa-location-dot"></i>&nbsp; Tracking ကြည့်ရန်</button>`;
    const html = `<div class="ly-chips">${chips}</div>${sum}${donut}<div class="ly-gt">Customer အလိုက် Order များ <span>${groups.length} ဦး</span></div>${gl || ''}${act}`;
    const box = $('ly4'); const f = document.activeElement; if (f && f.id === 'lyFreight') return;
    box.innerHTML = html;
  }

  function onClick(e) {
    const chip = e.target.closest('[data-sel]'); if (chip) { sel = chip.dataset.sel; sig = ''; return renderLY(); }
    const ev = e.target.closest('[data-ev]'); if (ev) { const isP = sel === '__pool', gg = isP ? null : gateOf(sel), src = isP ? pool() : (gg ? gg.items : []); return window.klVoucherLY(src.filter(i => buyerOf(i) === ev.dataset.ev), ev.dataset.ev, gg ? gg.gate : '', !isP); }
    const eo = e.target.closest('[data-eo]'); if (eo) return window.lyEditOrder(eo.dataset.eo);
    const eg = e.target.closest('[data-eg]'); if (eg) return window.lyEditGroup(eg.dataset.eg);
    const tg = e.target.closest('[data-tg]'); if (tg) { const k = sel + '|' + tg.dataset.tg; openG.has(k) ? openG.delete(k) : openG.add(k); sig = ''; return renderLY(); }
    const act = e.target.closest('[data-act]'); if (act) { if (act.dataset.act === 'send') { try { openGateSendModal(); } catch (er) {} } else if (act.dataset.act === 'gv') window.gvGate && window.gvGate(sel); else if (act.dataset.act === 'gs') window.gvGate && window.gvGate(sel, true); else window.openKismetGateTrack && window.openKismetGateTrack(sel); }
  }
  function onChange(e) {
    if (e.target.id !== 'lyFreight') return;
    const g = gateOf(sel); if (!g) return;
    const v = Math.max(0, num(e.target.value)); g.freight = v; g.totalFee = v; realloc(g); persist(); toast('✅ တန်ဆာခကို Kg % အလိုက် ခွဲတွက်ပြီးပါပြီ');
  }

  /* re-render when data changes */
  setInterval(() => {
    try {
      const p = page(); if (!p || p.classList.contains('hidden')) return; ensureShell();
      const s = mode + sel + JSON.stringify([...openG]) + gates().map(g => g.id + g.freight + (g.items || []).map(i => i.id + i.kg + i.buyer + i.name + i.gateFee).join(',')).join('|') + pool().map(i => i.id + i.kg + i.buyer + i.name).join(',');
      if (s !== sig) { sig = s; renderLY(); }
    } catch (e) {}
  }, 700);
  setTimeout(() => { try { ensureShell(); applyMode(); } catch (e) {} }, 400);

  /* ================= 2. Edit order / edit group ================= */
  function sheet(html) {
    let w = $('lyEdit'); if (!w) { w = document.createElement('div'); w.id = 'lyEdit'; w.className = 'ly-ov'; w.addEventListener('click', (e) => { if (e.target === w) w.classList.add('ly-off'); }); document.body.appendChild(w); }
    w.innerHTML = `<div class="ly-sh">${html}</div>`; w.classList.remove('ly-off'); return w;
  }
  const closeEdit = () => { const w = $('lyEdit'); if (w) w.classList.add('ly-off'); };
  const fld = (label, id, val, type, extra) => `<label class="ly-f"><span>${label}</span><input id="${id}" type="${type || 'text'}" ${type === 'number' ? 'inputmode="decimal" step="any"' : ''} value="${esc(val)}" ${extra || ''}></label>`;
  function buyersList() { const s = new Set(); routeItems().concat(...gates().map(g => g.items || [])).forEach(i => { if ((i.buyer || '').trim()) s.add(i.buyer.trim()); }); return [...s]; }

  window.lyEditOrder = function (id) {
    let it = routeItems().find(i => i.id === id), g = gateOfItem(id);
    if (!it && g) it = g.items.find(i => i.id === id);
    if (!it) return toast('ပစ္စည်း မတွေ့ပါ');
    let meth = ['Air', 'Land', 'Post'].includes(it.method) ? it.method : 'Air'; const oldM = meth;
    const ML = { Air: ['fa-plane', 'လေယာဉ်'], Land: ['fa-truck-fast', 'ကား'], Post: ['fa-envelope', 'စာတိုက်'] };
    const segs = () => ['Air', 'Land', 'Post'].map(k => `<button type="button" class="kt-segb${k === meth ? ' on' : ''}" data-lm="${k}"><i class="fa-solid ${ML[k][0]}"></i><span>${ML[k][1]}</span></button>`).join('');
    sheet(`<div class="ly-sh-t">Order ပြင်ရန်</div>
      ${fld('ပစ္စည်းအမည်', 'lyeName', it.name || '')}
      ${fld('Customer (မှာထားသူ)', 'lyeBuyer', it.buyer || '', 'text', 'list="lyBuyers"')}<datalist id="lyBuyers">${buyersList().map(b => `<option value="${esc(b)}">`).join('')}</datalist>
      ${fld('မှာတဲ့နေရာ', 'lyeSource', it.source || '')}
      <div class="ly-2">${fld('Qty (ခု)', 'lyeQty', it.qty || 1, 'number')}${fld('Kg', 'lyeKg', num(it.kg), 'number')}</div>
      <div class="ly-2">${fld('ဈေး (တစ်ခု)', 'lyePrice', num(it.price), 'number')}${fld('မှတ်ချက် / Tracking', 'lyeNote', it.note || '')}</div>
      <div class="ly-rate" id="lyeCost" style="text-align:left;margin-top:8px"></div>
      ${g ? `<p class="ly-hint" style="margin-top:8px">ဂိတ်တင်ပြီးသား ပစ္စည်းဖြစ်လို့ ပို့ဆောင်ပုံကို ဂိတ် Tracking ထဲက ပြောင်းပါ။</p>` : `<div class="ly-f"><span>တရုတ် → လားရှိုး ပို့ဆောင်ပုံ</span><div class="kt-seg" id="lyeMeth" style="margin-top:4px">${segs()}</div></div>`}
      <div class="ly-btns"><button type="button" class="ly-b0" id="lyeCancel">မလုပ်တော့ပါ</button><button type="button" class="ly-b1" id="lyeSave">သိမ်းမည်</button></div>`);
    const cost = () => { const c = Math.max(1, parseInt($('lyeQty').value) || 1) * num($('lyePrice').value); $('lyeCost').textContent = c > 0 ? 'Order Cost = ' + fmt(c) + ' Ks' : ''; };
    $('lyeQty').oninput = cost; $('lyePrice').oninput = cost; cost();
    if ($('lyeMeth')) $('lyeMeth').onclick = (e) => { const b = e.target.closest('[data-lm]'); if (!b) return; meth = b.dataset.lm; $('lyeMeth').innerHTML = segs(); };
    $('lyeCancel').onclick = closeEdit;
    $('lyeSave').onclick = () => {
      it.name = $('lyeName').value.trim() || it.name; it.buyer = $('lyeBuyer').value.trim(); it.source = $('lyeSource').value.trim();
      it.qty = Math.max(1, parseInt($('lyeQty').value) || 1); it.kg = Math.max(0, num($('lyeKg').value)); it.price = Math.max(0, num($('lyePrice').value)); it.note = $('lyeNote').value.trim();
      if (!g && meth !== oldM) { it.method = meth; try { recalculateRouteFees(oldM); recalculateRouteFees(meth); } catch (e) {} }
      realloc(g); closeEdit(); persist(); toast('✅ Order ပြင်ပြီးပါပြီ');
    };
  };
  window.lyEditGate = function (gid) {
    const g = gateOf(gid); if (!g) return;
    sheet(`<div class="ly-sh-t">ဂိတ်စာရင်း ပြင်ရန်</div>${fld('ဂိတ် / အမည်', 'lygtName', g.gate || '')}${fld('မှတ်ချက် (ကားနံပါတ်၊ ဖုန်း စသည်)', 'lygtNote', g.note || '')}${fld('ရက်စွဲ', 'lygtDate', g.date || '', 'date')}
      <div class="ly-btns"><button type="button" class="ly-b0" id="lygtCancel">မလုပ်တော့ပါ</button><button type="button" class="ly-b1" id="lygtSave">သိမ်းမည်</button></div>`);
    $('lygtCancel').onclick = closeEdit;
    $('lygtSave').onclick = () => { g.gate = $('lygtName').value.trim() || g.gate; g.note = $('lygtNote').value.trim(); g.date = $('lygtDate').value || g.date; closeEdit(); persist(); toast('✅ ဂိတ်စာရင်း ပြင်ပြီးပါပြီ'); };
  };
  window.lyEditGroup = function (name) {
    const isPool = sel === '__pool', g = isPool ? null : gateOf(sel), items = (isPool ? pool() : (g ? g.items : [])).filter(i => buyerOf(i) === name);
    if (!items.length) return;
    sheet(`<div class="ly-sh-t">Group ပြင်ရန်</div><p class="ly-hint">${items.length} order ပါတယ်။ နာမည်ပြောင်းရင် ဒီ group ထဲက order အားလုံး ပြောင်းမယ်၊ တူတဲ့ နာမည်ရှိရင် အလိုလို ပေါင်းမယ်။</p>
      ${fld('Customer နာမည်', 'lygName', name === NONAME ? '' : name, 'text', 'list="lyBuyers2"')}<datalist id="lyBuyers2">${buyersList().map(b => `<option value="${esc(b)}">`).join('')}</datalist>
      <div class="ly-btns"><button type="button" class="ly-b0" id="lygCancel">မလုပ်တော့ပါ</button><button type="button" class="ly-b1" id="lygSave">သိမ်းမည်</button></div>`);
    $('lygCancel').onclick = closeEdit;
    $('lygSave').onclick = () => { const nn = $('lygName').value.trim(); items.forEach(i => { i.buyer = nn; }); closeEdit(); persist(); toast('✅ Group ပြင်ပြီးပါပြီ'); };
  };

  /* ================= 3. Gate-send list: arrived items, grouped by customer, Kg only ================= */
  window.renderGateSendList = function () {
    const arrived = pool(), groups = groupItems(arrived, null); let h = '';
    groups.forEach(gr => {
      const all = gr.items.every(i => gateSelectedIds.has(i.id));
      h += `<div class="ly-sg"><div class="ly-sgh"><span>${esc(gr.name)} <em>(${gr.items.length})</em></span><button type="button" data-sb="${esc(gr.name)}">${all ? 'ပယ်ဖျက်' : 'အားလုံးရွေး'}</button></div>`;
      gr.items.forEach(i => { h += `<label class="ly-sr"><input type="checkbox" ${gateSelectedIds.has(i.id) ? 'checked' : ''} data-si="${esc(i.id)}"><span class="ly-srn">${esc(i.name)} <em>x${esc(i.qty || 1)}</em></span><span class="ly-srk">${num(i.kg)} Kg</span></label>`; });
      h += '</div>';
    });
    const el = $('gateSendList'); if (!el) return;
    el.innerHTML = h || '<div class="ly-empty">ပစ္စည်း မရှိပါ</div>';
    if (!el.__lyBound) {
      el.__lyBound = true;
      el.addEventListener('change', (e) => { const c = e.target.closest('[data-si]'); if (c) { c.checked ? gateSelectedIds.add(c.dataset.si) : gateSelectedIds.delete(c.dataset.si); window.updateGateSelSummary(); } });
      el.addEventListener('click', (e) => { const b = e.target.closest('[data-sb]'); if (!b) return; const gr = groupItems(pool(), null).find(x => x.name === b.dataset.sb); if (!gr) return; const all = gr.items.every(i => gateSelectedIds.has(i.id)); gr.items.forEach(i => all ? gateSelectedIds.delete(i.id) : gateSelectedIds.add(i.id)); window.renderGateSendList(); });
    }
    window.updateGateSelSummary();
  };
  window.updateGateSelSummary = function () {
    const sel2 = pool().filter(i => gateSelectedIds.has(i.id)), kg = sel2.reduce((a, i) => a + num(i.kg), 0);
    const fr = num(($('gateFreightInput') || {}).value);
    const el = $('gateSelSummary'); if (!el) return;
    el.innerText = sel2.length ? `ရွေးထားသည်: ${sel2.length} မျိုး • ${kg.toFixed(2)} Kg` + (fr > 0 && kg > 0 ? ` • Kg တစ်ခုလျှင် ≈ ${fmt(fr / kg)} Ks` : '') : 'ရွေးထားခြင်း မရှိသေးပါ';
  };
  window.lyRefresh = () => { sig = ''; renderLY(); };
})();
