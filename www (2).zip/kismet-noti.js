/* KISMET — system notifications + vibration (restores LocalNotifications / Haptics hook) */
(function () {
  if (window.__notiLoaded) return; window.__notiLoaded = true;
  const cap = (n) => (window.Capacitor && window.Capacitor.Plugins) ? window.Capacitor.Plugins[n] : null;
  const CH = 'kismet_alerts_v2';
  let ready = false, forceNative = false, seq = 0;

  async function init() {
    const LN = cap('LocalNotifications'); if (!LN) return false; if (ready) return true;
    try {
      let p = await LN.checkPermissions();
      if (p.display !== 'granted') p = await LN.requestPermissions();
      if (LN.createChannel) await LN.createChannel({ id: CH, name: 'KISMET Alerts', description: 'အဖွဲ့ဝင်များ၏ အသိပေးချက်များ', importance: 5, visibility: 1, vibration: true, lights: true, lightColor: '#F26419' });
      ready = p.display === 'granted';
    } catch (e) {}
    return ready;
  }

  function buzz() {
    try { const H = cap('Haptics'); if (H && H.vibrate) H.vibrate({ duration: 450 }); } catch (e) {}
    try { if (navigator.vibrate) navigator.vibrate([400, 120, 480]); } catch (e) {}
  }

  async function notify(title, body) {
    buzz();
    const LN = cap('LocalNotifications'); if (!LN) return;
    const background = document.hidden || (document.hasFocus && !document.hasFocus());
    if (!background && !forceNative) return;               // app is open: in-app banner + sound + vibration are enough
    forceNative = false;
    if (!(await init())) return;
    try { await LN.schedule({ notifications: [{ id: Math.floor(Date.now() % 2000000000) + (seq++ % 997), title, body, channelId: CH, iconColor: '#F26419' }] }); } catch (e) {}
  }

  function hook() {
    if (window.__notiHooked) return true;
    const o = window.triggerNotificationAlert; if (typeof o !== 'function') return false;
    window.triggerNotificationAlert = function (sender, msg) {
      const r = o.apply(this, arguments);
      notify('KISMET • ' + (sender || 'Alert'), String(msg || 'အသိပေးချက်အသစ်'));
      return r;
    };
    const t = window.testVibrationAndSound;
    if (typeof t === 'function') window.testVibrationAndSound = function () { forceNative = true; return t.apply(this, arguments); };
    window.__notiHooked = true; return true;
  }

  // ask for permission as soon as the app opens (Android 13+ needs it) and again on the first tap if still pending
  setTimeout(() => { init(); }, 900);
  document.addEventListener('click', function once() { document.removeEventListener('click', once, true); init(); }, true);
  const iv = setInterval(() => { if (hook()) clearInterval(iv); }, 300);
  window.kismetNotify = notify;
})();
