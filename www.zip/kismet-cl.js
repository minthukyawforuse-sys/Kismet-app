/* KISMET — China → Lashio: Kg rate (Ks/Kg), customer-group fees, group E-Voucher (also used by Lashio → Yangon) */
(function () {
  if (window.__clLoaded) return; window.__clLoaded = true;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toast = (m) => { try { if (typeof showToast === 'function') showToast(m); } catch (e) {} };
  const num = (v) => parseFloat(v) || 0;
  const fmt = (n) => Math.round(n).toLocaleString();
  const NONAME = '(နာမည်မရှိ)';
  const PAL = ['#8ecff5', '#ffb27a', '#7fcf8e', '#c08bf5', '#7a7fe0', '#e4e68f', '#9be58a', '#8a8a8e', '#ef6b6b', '#f5a3c7'];
  const TAB_LABEL = { Air: '✈️ Air', Land: '🚚 Land', Post: '📦 Post', All: '🌐 အားလုံး' };
  const buyerOf = (i) => (i.buyer || '').trim() || NONAME;
  let sig = '', openG = new Set();

  const modeNow = () => { try { return localStorage.getItem('kismet_kgpage_mode') || 'LY'; } catch (e) { return 'LY'; } };
  const tabNow = () => { try { return currentKgRouteTab; } catch (e) { return 'Air'; } };
  const items = () => { try { const t = tabNow(); return (allRouteRecords[ROUTE_KEY] || []).filter(i => i && i.arrived && (t === 'All' || (i.method || 'Air') === t)); } catch (e) { return []; } };

  function groupBy(list) {
    const m = new Map();
    list.forEach(i => { const k = buyerOf(i); if (!m.has(k)) m.set(k, { name: k, items: [], kg: 0, fee: 0 }); const g = m.get(k); g.items.push(i); g.kg += num(i.kg); g.fee += num(i.fee); });
    return [...m.values()].sort((a, b) => b.kg - a.kg || a.name.localeCompare(b.name));
  }

  /* ---------- E-Voucher (shared) ---------- */
  window.klVoucher = function (v) {
    const area = $('eVoucherContentArea'), modal = $('eVoucherModal'); if (!area || !modal) return;
    const hasFee = v.fee !== null && v.fee !== undefined;
    const rows = v.rows.map((r, i) => `<tr class="border-b border-slate-100">
      <td class="py-1.5 text-slate-800 font-semibold">${i + 1}. ${esc(r.name)}</td>
      <td class="py-1.5 text-center text-slate-700 font-bold">${esc(r.qty)}</td>
      <td class="py-1.5 text-right text-slate-700 font-bold">${num(r.kg).toFixed(2)}</td>
      ${hasFee ? `<td class="py-1.5 text-right text-slate-900 font-bold">${fmt(num(r.fee))}</td>` : ''}</tr>`).join('');
    const rate = hasFee && v.kg > 0 ? v.fee / v.kg : 0;
    area.innerHTML = `
      <div class="text-center border-b-2 border-dashed border-slate-300 pb-4 pt-2 flex flex-col items-center justify-center">
        <h2 class="text-2xl font-black text-slate-900 tracking-widest uppercase">KISMET</h2>
        <p class="text-[10px] text-slate-500 mt-1.5 font-medium">${esc(v.title)} • ${esc(v.date || new Date().toISOString().slice(0, 10))}</p>
      </div>
      <div class="space-y-1 text-[11px] bg-slate-50 p-3 rounded-xl border border-slate-200 text-center mt-3">
        <div><span class="text-slate-500">Group / Customer:</span> <strong class="text-slate-900">${esc(v.group)}</strong></div>
        ${v.sub ? `<div><span class="text-slate-500">${esc(v.sub[0])}:</span> <strong class="text-orange-600">${esc(v.sub[1])}</strong></div>` : ''}
      </div>
      <table class="w-full text-[11px]">
        <thead><tr class="border-b border-slate-300 text-slate-500">
          <th class="text-left py-1">ပစ္စည်းအမည်</th><th class="text-center py-1">Qty</th><th class="text-right py-1">Kg</th>${hasFee ? '<th class="text-right py-1">တန်ဆာခ</th>' : ''}
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="border-t-2 border-dashed border-slate-300 pt-2 space-y-1 text-xs">
        <div class="flex justify-between text-slate-600"><span>စုစုပေါင်း Kg:</span><span>${num(v.kg).toFixed(2)} Kg</span></div>
        ${hasFee && rate > 0 ? `<div class="flex justify-between text-slate-600"><span>Kg တစ်ခုလျှင်:</span><span>${fmt(rate)} Ks</span></div>` : ''}
        ${hasFee ? `<div class="flex justify-between text-sm font-extrabold text-slate-900 pt-1"><span>စုစုပေါင်း တန်ဆာခ:</span><span class="text-orange-600">${fmt(v.fee)} Ks</span></div>` : ''}
      </div>
      <div class="text-center text-[10px] text-slate-400 pt-1">ဝယ်ယူအားပေးမှုကို အထူးကျေးဇူးတင်ရှိပါသည် 🙏</div>`;
    modal.classList.remove('hidden');
  };

  function voucherFor(list, group, title, sub, withFee) {
    const kg = list.reduce((a, i) => a + num(i.kg), 0), fee = list.reduce((a, i) => a + num(withFee === 'gate' ? i.gateFee : i.fee), 0);
    window.klVoucher({ title, group, sub, kg, fee: withFee ? fee : null, rows: list.map(i => ({ name: i.name, qty: i.qty || 1, kg: i.kg, fee: withFee === 'gate' ? i.gateFee : i.fee })) });
  }
  window.klVoucherCL = function (name) {
    const list = name === '*' ? items() : items().filter(i => buyerOf(i) === name);
    if (!list.length) return;
    voucherFor(list, name === '*' ? 'အားလုံး' : name, 'တရုတ် → လားရှိုး တန်ဆာခ ဘောင်ချာ', ['လမ်းကြောင်း', TAB_LABEL[tabNow()] || tabNow()], 'fee');
  };
  window.klVoucherLY = function (list, name, gate, withFee) {
    if (!list || !list.length) return;
    voucherFor(list, name, 'လားရှိုး → ရန်ကုန် တန်ဆာခ ဘောင်ချာ', gate ? ['ဂိတ်', gate] : null, withFee ? 'gate' : null);
  };

  /* ---------- China → Lashio panel on page 4 ---------- */
  function shell() {
    const p = $('page-4'); if (!p) return false;
    if ($('cl4')) return true;
    const anchor = $('editableTotalKgInput'); const box = anchor && anchor.closest('.bg-neutral-950');
    if (!box || !box.parentNode) return false;
    const d = document.createElement('div'); d.id = 'cl4'; d.className = 'ly';
    box.parentNode.insertBefore(d, box.nextSibling);
    d.addEventListener('click', onClick); d.addEventListener('change', onChange);
    return true;
  }

  function render() {
    if (!shell()) return;
    const d = $('cl4'); const f = document.activeElement; if (f && f.id === 'clRate') return;
    if (modeNow() !== 'CL') { d.style.display = 'none'; return; }
    d.style.display = '';
    const tab = tabNow(), list = items(), groups = groupBy(list);
    const kgTot = list.reduce((a, i) => a + num(i.kg), 0), feeTot = list.reduce((a, i) => a + num(i.fee), 0);
    let rate = 0;
    try { const ov = (allRouteOverrides[ROUTE_KEY] || {})[tab]; rate = ov ? num(ov.rate) : 0; } catch (e) {}
    const effRate = kgTot > 0 ? feeTot / kgTot : 0;
    const rateBox = tab === 'All'
      ? `<div class="ly-hint">Kg တစ်ခု ဈေးသတ်မှတ်ရန် Air / Land / Post တစ်ခုချင်း ရွေးပါ</div>`
      : `<label class="ly-f" style="margin-top:0"><span>${TAB_LABEL[tab]} — Kg တစ်ခုလျှင် ဈေး (Ks / Kg)</span><input id="clRate" type="number" inputmode="decimal" min="0" step="any" value="${rate || ''}" placeholder="${effRate > 0 ? Math.round(effRate) : '0'}"></label>
         <div class="ly-rate">${rate > 0 ? `${kgTot.toFixed(2)} Kg × ${fmt(rate)} = <b style="color:#fb923c">${fmt(kgTot * rate)} Ks</b> • Customer Group အလိုက် Kg % ဖြင့် ခွဲပေးထားသည်` : 'ဈေးထည့်လိုက်ရင် Group အားလုံး၏ တန်ဆာခ တစ်ခါတည်း တွက်ပေးမယ်'}</div>`;
    const gl = groups.map((g, i) => {
      const pct = kgTot > 0 ? g.kg / kgTot * 100 : 100 / groups.length, open = openG.has(g.name);
      return `<div class="ly-g"><div class="ly-gh" data-tg="${esc(g.name)}"><i class="ly-dot" style="background:${PAL[i % PAL.length]}"></i>
        <div class="ly-gm"><div class="ly-gn">${esc(g.name)}</div><div class="ly-gs">${g.items.length} order • ${g.kg.toFixed(2)} Kg • ${pct.toFixed(1)}%</div></div>
        <b class="ly-fee">${fmt(g.fee)} Ks</b>
        <button type="button" class="ly-ib" data-ev="${esc(g.name)}" title="E-Voucher ဘောင်ချာ"><i class="fa-solid fa-receipt"></i></button>
        <button type="button" class="ly-ib" data-eg="${esc(g.name)}" title="Group နာမည်ပြင်ရန်"><i class="fa-solid fa-pen"></i></button>
        <i class="fa-solid fa-chevron-${open ? 'up' : 'down'} ly-chev"></i></div>
        ${open ? `<div class="ly-gb">${g.items.map(it => `<div class="ly-o"><div class="ly-om"><div class="ly-on">${esc(it.name)} <span>x${esc(it.qty || 1)}</span></div><div class="ly-os">${num(it.kg)} Kg${it.note ? ' • ' + esc(it.note) : ''}</div></div><b class="ly-fee">${fmt(num(it.fee))} Ks</b></div>`).join('')}</div>` : ''}</div>`;
    }).join('');
    d.innerHTML = `<div class="bg-neutral-950 p-3.5 rounded-2xl border border-neutral-800" style="margin-top:12px">${rateBox}</div>
      <div class="ly-gt">Customer Group အလိုက် တန်ဆာခ <span>${groups.length} ဦး • ${kgTot.toFixed(2)} Kg • ${fmt(feeTot)} Ks</span></div>
      ${gl || '<div class="ly-empty">လားရှိုးရောက်ပြီး ပစ္စည်း မရှိသေးပါ (စာမျက်နှာ ၂ တွင် ✅ ရောက်ပြီ နှိပ်ပါ)</div>'}
      ${groups.length ? `<button type="button" class="ly-act" data-ev="*"><i class="fa-solid fa-receipt"></i>&nbsp; Group အားလုံး ဘောင်ချာ</button>` : ''}`;
  }

  function onChange(e) {
    if (e.target.id !== 'clRate') return;
    const tab = tabNow(); if (tab === 'All') return;
    if (typeof checkPermission === 'function' && !checkPermission('route')) return;
    const ov = getRouteOverrideObj(tab); ov.rate = Math.max(0, num(e.target.value)); ov.totalFee = null;
    if (ov.rate > 0) { recalculateRouteFees(tab); }
    saveToLocalStorage(); renderAll(); sig = ''; render();
    toast(ov.rate > 0 ? `✅ ${fmt(ov.rate)} Ks / Kg ဖြင့် Group အလိုက် တွက်ပြီးပါပြီ` : 'Kg ဈေး ဖယ်ရှားပြီးပါပြီ');
  }

  function onClick(e) {
    const ev = e.target.closest('[data-ev]'); if (ev) return window.klVoucherCL(ev.dataset.ev);
    const eg = e.target.closest('[data-eg]'); if (eg) return renameGroup(eg.dataset.eg);
    const tg = e.target.closest('[data-tg]'); if (tg) { const k = tg.dataset.tg; openG.has(k) ? openG.delete(k) : openG.add(k); sig = ''; render(); }
  }

  function renameGroup(name) {
    const its = items().filter(i => buyerOf(i) === name); if (!its.length) return;
    let w = $('clEdit'); if (!w) { w = document.createElement('div'); w.id = 'clEdit'; w.className = 'ly-ov'; w.addEventListener('click', (e) => { if (e.target === w) w.classList.add('ly-off'); }); document.body.appendChild(w); }
    w.innerHTML = `<div class="ly-sh"><div class="ly-sh-t">Group ပြင်ရန်</div><p class="ly-hint">${its.length} order ပါတယ်။ နာမည်ပြောင်းရင် ဒီ group ထဲက order အားလုံး ပြောင်းမယ်၊ တူတဲ့ နာမည်ရှိရင် ပေါင်းမယ်။</p>
      <label class="ly-f"><span>Customer နာမည်</span><input id="clgName" value="${esc(name === NONAME ? '' : name)}"></label>
      <div class="ly-btns"><button type="button" class="ly-b0" id="clgCancel">မလုပ်တော့ပါ</button><button type="button" class="ly-b1" id="clgSave">သိမ်းမည်</button></div></div>`;
    w.classList.remove('ly-off');
    $('clgCancel').onclick = () => w.classList.add('ly-off');
    $('clgSave').onclick = () => { const nn = $('clgName').value.trim(); its.forEach(i => { i.buyer = nn; }); w.classList.add('ly-off'); saveToLocalStorage(); renderAll(); sig = ''; render(); toast('✅ Group ပြင်ပြီးပါပြီ'); };
  }

  setInterval(() => {
    try {
      const p = $('page-4'); if (!p || p.classList.contains('hidden')) return; shell();
      const s = modeNow() + tabNow() + JSON.stringify([...openG]) + items().map(i => i.id + i.kg + i.fee + i.buyer + i.name).join(',');
      if (s !== sig) { sig = s; render(); }
    } catch (e) {}
  }, 600);
  window.clRefresh = () => { sig = ''; render(); };
})();
