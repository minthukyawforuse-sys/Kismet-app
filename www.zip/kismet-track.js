/* KISMET tracking add-on v3 */
(function () {
  if (window.__ktLoaded) return; window.__ktLoaded = true;
  const $ = (id) => document.getElementById(id);
  const cap = (n) => (window.Capacitor && window.Capacitor.Plugins) ? window.Capacitor.Plugins[n] : null;
  const toast = (m) => { try { if (typeof showToast === 'function') showToast(m); } catch (e) {} };
  const haptic = () => { try { const H = cap('Haptics'); if (H && H.impact) H.impact({ style: 'LIGHT' }); else if (navigator.vibrate) navigator.vibrate(25); } catch (e) {} };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---------- 1. Gallery / file saving ---------- */
  const blobToB64 = (b) => new Promise((res, rej) => { const f = new FileReader(); f.onloadend = () => res(f.result); f.onerror = rej; f.readAsDataURL(b); });
  function interceptSave(a) {
    try {
      const saver = cap('KismetSaver'); if (!saver || !a) return false;
      const href = a.href || a.getAttribute('href') || '';
      const dl = a.download || a.getAttribute('download') || ('KISMET_' + Date.now() + '.png');
      if (!href) return false;
      const okImg = () => { toast('✅ Gallery (Pictures/KISMET) ထဲ သိမ်းပြီးပါပြီ'); haptic(); };
      const bad = (e) => toast('⚠️ Save Error: ' + (e && e.message ? e.message : 'Failed'));
      if (href.startsWith('data:image/')) { saver.saveImage({ base64: href, filename: dl }).then(okImg).catch(bad); return true; }
      if (href.startsWith('blob:')) {
        fetch(href).then(r => r.blob()).then(b => {
          if ((b.type && b.type.startsWith('image/')) || /\.(png|jpg|jpeg|webp)$/i.test(dl))
            return blobToB64(b).then(u => saver.saveImage({ base64: u, filename: dl })).then(okImg);
          return b.text().then(t => saver.saveFile({ text: t, filename: dl, mime: b.type || 'text/csv' }))
            .then(() => { toast('✅ Download/KISMET ထဲ သိမ်းပြီးပါပြီ'); haptic(); });
        }).catch(bad);
        return true;
      }
    } catch (e) {}
    return false;
  }
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () { if (interceptSave(this)) return; return origClick.apply(this, arguments); };

  /* ---------- 2. Icons (small, minimal) ---------- */
  const FAI = { Air: 'fa-plane', Land: 'fa-truck-fast', Post: 'fa-envelope' };
  const LBL = { Air: 'လေယာဉ်', Land: 'ကား', Post: 'စာတိုက်' };
  const GLBL = { Air: 'လေယာဉ်', Land: 'ကားဂိတ်', Post: 'စာတိုက်' };
  const ico = (m) => `<i class="fa-solid ${FAI[m] || FAI.Air}"></i>`;

  /* ---------- 3. Data helpers ---------- */
  const allItems = () => {
    try { if (typeof allRouteRecords !== 'undefined') return Object.values(allRouteRecords).reduce((a, l) => a.concat(Array.isArray(l) ? l : []), []); } catch (e) {}
    return [];
  };
  const gates = () => { try { return typeof gateShipments !== 'undefined' ? gateShipments : []; } catch (e) { return []; } };
  function findItem(id) {
    const d = allItems().find(x => x && x.id === id); let gate = null;
    for (const g of gates()) { const it = (g.items || []).find(x => x && x.id === id); if (it) { gate = g; if (!d) return { item: it, gate }; break; } }
    return d ? { item: d, gate } : null;
  }
  const mOf = (it) => (it && FAI[it.method]) ? it.method : 'Air';
  const tOf = (g) => (g && FAI[g.transport]) ? g.transport : 'Land';
  const stageItem = (it, g) => g && g.checked ? 4 : g ? 3 : it && it.arrived ? 2 : 1;
  const stageGate = (g) => g.checked ? 4 : 3;
  const STATE = ['', 'လမ်းမှာ', 'လားရှိုး', 'လမ်းမှာ', 'ရောက်ပြီ'];
  function trackId(t) { const m = String(t || '').trim().match(/\b([A-Za-z]{1,4}\d{6,22}|\d{8,22})\b/); return m ? m[1].toUpperCase() : ''; }
  function courier(id) {
    if (!id) return 'China Courier';
    if (/^JT\d{8,}$/.test(id)) return 'J&T Express (极兔速递)';
    if (/^SF\d{8,}$/.test(id)) return 'SF Express (顺丰速运)';
    if (/^YT\d{8,}$/.test(id)) return 'YTO Express (圆通速递)';
    if (/^(75|78|73|54)\d{8,}$/.test(id)) return 'ZTO Express (中通快递)';
    if (/^77\d{9,}$/.test(id)) return 'STO Express (申通快递)';
    if (/^(43|46|31)\d{9,}$/.test(id)) return 'Yunda Express (韵达快递)';
    return 'China Courier';
  }
  const fmtDate = (ms) => new Date(ms).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const gKgS = (g) => (g.items || []).reduce((a, i) => a + (parseFloat(i.kg) || 0), 0);
  const gFeeS = (g) => parseFloat(g.freight) || 0;

  /* ---------- 4. Route line + rows ---------- */
  const barHTML = (stage, m) => `<div class="kt-bar"><div class="kt-bar-bg"></div><div class="kt-bar-fill"></div><i class="kt-nd" style="left:0"></i><i class="kt-nd" style="left:50%"></i><i class="kt-nd" style="left:100%"></i><div class="kt-run"><i class="fa-solid ${stage === 4 ? 'fa-check' : FAI[m]}"></i></div></div>
    <div class="kt-bar-lb"><span>တရုတ်</span><span>လားရှိုး</span><span>ရန်ကုန်</span></div>`;
  function rowHTML(o) {
    return `<div class="kt-pc ${o.card ? 'kt-card ' : ''}kt-s${o.stage}" data-k="${o.kind}" data-id="${esc(o.id)}">
      <div class="kt-pc-top"><div class="kt-pc-nm"><div class="kt-pc-t">${esc(o.name)}</div><div class="kt-pc-s">${esc(o.sub)}</div></div><span class="kt-pc-st">${esc(o.st || STATE[o.stage])}</span></div>
      ${barHTML(o.stage, o.m)}</div>`;
  }
  let pFilter = 'All', pAll = false, lastSig = '';
  function rowData() {
    const out = [];
    allItems().forEach(it => { const id = trackId(it.note); out.push({ kind: 'item', id: it.id, m: mOf(it), stage: stageItem(it, null), name: it.name || 'ပစ္စည်း', sub: (id ? id + ' • ' : (it.buyer ? it.buyer + ' • ' : '')) + (parseFloat(it.kg) || 0) + ' Kg' }); });
    gates().forEach(g => out.push({ kind: 'gate', id: g.id, m: tOf(g), stage: stageGate(g), name: g.gate, sub: GLBL[tOf(g)] + ' • ' + (g.items || []).length + ' မျိုး • ' + gKgS(g).toFixed(1) + ' Kg' }));
    out.sort((a, b) => (a.stage === 4) - (b.stage === 4));
    return out.filter(o => pFilter === 'All' || o.m === pFilter);
  }
  function buildPanel() {
    const p = document.createElement('div'); p.id = 'kismetRouteAnimPanel';
    p.addEventListener('click', (e) => {
      const chip = e.target.closest('[data-f]'); if (chip) { pFilter = chip.dataset.f; pAll = false; lastSig = ''; haptic(); return refreshPanel(); }
      if (e.target.closest('.kt-more')) { pAll = !pAll; lastSig = ''; return refreshPanel(); }
      const pc = e.target.closest('.kt-pc'); if (!pc || !pc.dataset.id) return;
      if (pc.dataset.k === 'gate') window.openKismetGateTrack(pc.dataset.id); else window.openKismetTrackModal(pc.dataset.id);
    });
    return p;
  }
  function refreshPanel() {
    const p = $('kismetRouteAnimPanel'); if (!p) return;
    const d = rowData(), sig = pFilter + pAll + d.map(o => o.kind + o.id + o.stage + o.name + o.sub + o.m).join('|');
    if (sig === lastSig) return; lastSig = sig;
    const show = pAll ? d : d.slice(0, 3);
    p.innerHTML = `<div class="kt-row"><div class="kt-hd-t"><b></b>တရုတ် - လားရှိုး - ရန်ကုန်</div>
      <div class="kt-tabs">${[['All', 'All'], ['Air', ico('Air')], ['Land', ico('Land')], ['Post', ico('Post')]].map(([k, l]) => `<button type="button" data-f="${k}" class="kt-tab${pFilter === k ? ' on' : ''}">${l}</button>`).join('')}</div></div>
      <div style="margin-top:6px">${show.length ? show.map(rowHTML).join('') : rowHTML({ kind: 'none', id: '', m: pFilter === 'All' ? 'Air' : pFilter, stage: 1, name: 'ပစ္စည်း မရှိသေးပါ', sub: 'ထည့်လိုက်ရင် ဒီမှာ Track ပေါ်မယ်' })}</div>
      ${d.length > 3 ? `<button type="button" class="kt-more">${pAll ? 'လျှော့ပြရန်' : 'အားလုံးကြည့်ရန် (' + d.length + ')'}</button>` : ''}`;
  }
  function placePanel() {
    let p = $('kismetRouteAnimPanel');
    const mode = (typeof currentMainMode !== 'undefined') ? currentMainMode : 'dashboard';
    if (!p) { p = buildPanel(); lastSig = ''; }
    if (mode === 'shop') { p.classList.add('kt-hidden'); return; }
    p.classList.remove('kt-hidden');
    const host = mode === 'route' ? $('section-route') : $('page-dashboard');
    if (!host) return;
    if (p.parentElement !== host) { host.insertBefore(p, mode === 'route' ? host.firstChild : (host.firstElementChild ? host.firstElementChild.nextSibling : null)); lastSig = ''; }
    refreshPanel();
  }
  setInterval(() => { try { placePanel(); } catch (e) {} }, 900);

  /* ---------- 5. Gate list (Lashio -> Yangon): same minimal rows ---------- */
  function gateRow(g) {
    const m = tOf(g), n = (g.items || []).length, got = (g.items || []).filter(i => i.got).length;
    const checking = !g.checked && (g.checking || got > 0);
    const st = g.checked ? 'ရန်ကုန်ရောက်ပြီ' : checking ? `စစ်နေဆဲ ${got}/${n}` : GLBL[m] + 'တင်ပြီး';
    return rowHTML({ kind: 'gate', id: g.id, card: true, m, stage: stageGate(g), name: g.gate, st, sub: `${n} မျိုး • ${gKgS(g).toFixed(2)} Kg • ${gFeeS(g) > 0 ? Math.round(gFeeS(g)).toLocaleString() + ' Ks' : 'တန်ဆာခ မထည့်ရသေး'}` });
  }
  const origRGL = window.renderGateLists;
  window.renderGateLists = function () {
    try {
      const g = gates();
      const html = g.length === 0 ? `<div class="deep-black-box p-2.5 rounded-xl text-center text-[11px] text-neutral-500">တင်ပို့ထားသော စာရင်း မရှိသေးပါ</div>` : g.map(gateRow).join('');
      ['dashGateList', 'page3GateList'].forEach(id => { const el = $(id); if (el) el.innerHTML = html; });
      ['dashGateBadge', 'page3GateBadge'].forEach(id => { const el = $(id); if (el) el.innerText = `${g.length} ခု`; });
    } catch (e) { if (origRGL) origRGL(); }
  };
  document.addEventListener('click', (e) => {
    const c = e.target.closest('#dashGateList .kt-pc, #page3GateList .kt-pc'); if (!c || e.target.closest('#ktSheetWrap')) return;
    window.openKismetGateTrack(c.dataset.id);
  });
  try { window.renderGateLists(); } catch (e) {}

  /* ---------- 6. Tracking sheet (minimal) ---------- */
  let cur = { mode: 'item', id: null, text: '' };
  const LI = (label, id, extra) => `<div class="kt-li"><span>${label}</span><b id="${id}" ${extra || ''}>-</b></div>`;

  function buildSheet() {
    const w = document.createElement('div'); w.id = 'ktSheetWrap'; w.className = 'kt-hidden';
    w.addEventListener('click', (e) => { if (e.target === w) closeTrack(); });
    w.innerHTML = `
    <div class="kt-sheet" id="ktSheet">
      <div class="kt-hd">
        <button type="button" class="kt-cbtn" id="ktClose"><i class="fa-solid fa-arrow-left"></i></button>
        <div class="kt-title">Tracking</div>
        <div style="display:flex;gap:6px"><button type="button" class="kt-cbtn" id="ktCopy"><i class="fa-regular fa-copy"></i></button><button type="button" class="kt-cbtn" id="ktShot"><i class="fa-solid fa-image"></i></button></div>
      </div>
      <div class="kt-body">
        <div class="kt-row" style="align-items:flex-start;margin-top:6px">
          <div style="min-width:0"><div class="kt-lab" id="ktCour">Tracking Id</div><div class="kt-idv" id="ktId">-</div></div>
          <span class="kt-pill" id="ktStatus">-</span>
        </div>
        <div class="kt-route kt-s1" id="ktRoute"></div>
        <div class="kt-cap"><span id="ktCreated"></span><span id="ktDest"></span></div>
        <div class="kt-list" id="ktGridItem">
          ${LI('ပစ္စည်း', 'ktName')}${LI('Customer', 'ktCust')}${LI('မှာတဲ့နေရာ', 'ktSrc')}${LI('Order Cost', 'ktCost', 'class="kt-or"')}${LI('တန်ဆာခ (တရုတ်-လားရှိုး)', 'ktFee', 'class="kt-or"')}<div id="ktFee2Row" style="display:none">${LI('တန်ဆာခ (လားရှိုး-ရန်ကုန်)', 'ktFee2', 'class="kt-or"')}</div>${LI('Quantity', 'ktQty')}${LI('Weight', 'ktKg')}
        </div>
        <div class="kt-list" id="ktGridGate" style="display:none">
          ${LI('ပို့ဆောင်ပုံ', 'ktGType')}${LI('အမည်', 'ktGName')}${LI('ပစ္စည်း', 'ktGCount')}${LI('စုစုပေါင်း Weight', 'ktGKg')}<div class="kt-li"><span>တန်ဆာခ (ကျပ်)</span><input id="ktGFreight" class="kt-in" type="number" inputmode="numeric" min="0" placeholder="0"></div>${LI('Kg တစ်ခုလျှင်', 'ktGRate', 'class="kt-or"')}${LI('မှတ်ချက်', 'ktGNote')}
        </div>
        <div class="kt-sec" id="ktLegLab"></div><div class="kt-seg" id="ktChoose"></div>
        <div class="kt-items" id="ktItems" style="display:none"></div>
        <div id="ktItemOnly">
          <div class="kt-crow">
            <div style="display:flex;align-items:center;gap:10px;min-width:0"><div class="kt-av" id="ktAv"></div><div style="min-width:0"><div class="kt-val" id="ktCName">Courier</div><div class="kt-lab" id="ktCRole"></div></div></div>
            <div style="display:flex;gap:8px"><button type="button" class="kt-rb" id="kt17"><i class="fa-solid fa-magnifying-glass-location"></i></button><button type="button" class="kt-rb" id="ktKd"><i class="fa-solid fa-globe"></i></button></div>
          </div>
          <div class="kt-edit"><input id="ktInput" placeholder="Tracking ID ထည့်/ပြင်ရန်..."><button type="button" id="ktSave">သိမ်း</button></div>
        </div>
        <button type="button" class="kt-manage" id="ktManage" style="display:none"><i class="fa-solid fa-clipboard-check"></i>&nbsp; စစ်ဆေးရန် / ပြင်ရန်</button>
      </div>
    </div>`;
    document.body.appendChild(w);
    $('ktClose').onclick = closeTrack;
    $('ktCopy').onclick = () => { if (!cur.text) return toast('ကူးစရာ မရှိသေးပါ'); try { copyTextToClipboard(cur.text); } catch (e) { toast(cur.text); } };
    $('ktSave').onclick = saveId; $('kt17').onclick = () => ext('17track'); $('ktKd').onclick = () => ext('kuaidi'); $('ktShot').onclick = shot;
    $('ktManage').onclick = () => { const id = cur.id; closeTrack(); try { openGateDetail(id); } catch (e) {} };
    return w;
  }
  function closeTrack() { const w = $('ktSheetWrap'); if (w) w.classList.add('kt-hidden'); lastSig = ''; try { window.renderGateLists(); } catch (e) {} }
  function ext(p) {
    const id = trackId($('ktInput').value) || cur.text;
    if (!id) return toast('Tracking ID အရင်ထည့်ပါ');
    window.open(p === 'kuaidi' ? 'https://m.kuaidi100.com/result.jsp?nu=' + encodeURIComponent(id) : 'https://t.17track.net/en#nums=' + encodeURIComponent(id), '_blank', 'noopener');
  }
  function persist() { try { saveToLocalStorage(); renderAll(); if (typeof renderGateLists === 'function') renderGateLists(); } catch (e) {} lastSig = ''; }
  function saveId() {
    const f = findItem(cur.id); if (!f) return;
    f.item.note = $('ktInput').value.trim(); persist(); render(); toast('✅ Tracking ID သိမ်းဆည်းပြီးပါပြီ');
  }
  function shot() {
    const el = $('ktSheet'); if (!el || typeof html2canvas !== 'function') return toast('html2canvas မရှိပါ');
    toast('ပုံထုတ်နေပါသည်...');
    const ms = el.style.maxHeight, ov = el.style.overflow; el.style.maxHeight = 'none'; el.style.overflow = 'visible';
    html2canvas(el, { scale: 2, backgroundColor: '#0e0e10', useCORS: true }).then(c => {
      el.style.maxHeight = ms; el.style.overflow = ov;
      const a = document.createElement('a'); a.href = c.toDataURL('image/png'); a.download = 'KISMET_Track_' + Date.now() + '.png'; a.click();
    }).catch(() => { el.style.maxHeight = ms; el.style.overflow = ov; toast('⚠️ ပုံထုတ်မရပါ'); });
  }
  function chooseMethod(m, f, stage) {
    let old = null;
    try {
      if (cur.mode === 'gate') { f.transport = m; }
      else if (stage >= 3 && f.gate) { f.gate.transport = m; }
      else { old = f.item.method || 'Air'; f.item.method = m; }
    } catch (e) {}
    cur.mode === 'gate' ? renderGate() : render();
    try { if (old && old !== m && typeof recalculateRouteFees === 'function') { recalculateRouteFees(old); recalculateRouteFees(m); } } catch (e) {}
    persist(); haptic();
    toast('✅ ' + LBL[m] + ' သို့ ပြောင်းပြီးပါပြီ');
  }
  function common(stage, m, legLab) {
    $('ktSheet').classList.toggle('kt-ok', stage === 4);
    const r = $('ktRoute'); r.className = 'kt-route kt-s' + stage; r.innerHTML = barHTML(stage, m);
    $('ktLegLab').textContent = legLab;
    const box = $('ktChoose'), f = cur.mode === 'gate' ? gates().find(x => x.id === cur.id) : findItem(cur.id);
    box.innerHTML = ['Air', 'Land', 'Post'].map(k => `<button type="button" class="kt-segb${k === m ? ' on' : ''}" data-m="${k}">${ico(k)}<span>${LBL[k]}</span></button>`).join('');
    box.querySelectorAll('button').forEach(b => { b.onclick = (ev) => { ev.stopPropagation(); if (b.dataset.m !== m) chooseMethod(b.dataset.m, f, stage); }; });
  }

  function render() {
    const f = findItem(cur.id); if (!f) return;
    cur.mode = 'item';
    const it = f.item, gate = f.gate, stage = stageItem(it, gate), m = stage >= 3 ? tOf(gate) : mOf(it);
    $('ktGridItem').style.display = ''; $('ktGridGate').style.display = 'none'; $('ktItems').style.display = 'none'; $('ktItemOnly').style.display = ''; $('ktManage').style.display = 'none';
    common(stage, m, stage >= 3 ? 'လားရှိုး → ရန်ကုန် ပို့ဆောင်ပုံ' : 'တရုတ် → လားရှိုး ပို့ဆောင်ပုံ');
    const pill = ['', 'တရုတ် → လားရှိုး လမ်းမှာ', 'လားရှိုးရောက်', GLBL[tOf(gate)] + 'တင်ပြီး • လမ်းမှာ', 'ရန်ကုန်ရောက်ပြီ'][stage];
    $('ktStatus').textContent = pill;
    const ts = (String(it.id).match(/(\d{13})/) || [])[1];
    $('ktCreated').textContent = ts ? 'Created, ' + fmtDate(+ts) : ''; $('ktDest').textContent = gate ? GLBL[tOf(gate)] + ' • ' + gate.gate : '';
    const ex = trackId(it.note); cur.text = ex || (it.note ? String(it.note).trim() : '');
    $('ktCour').textContent = ex ? courier(ex) : 'Tracking Id'; $('ktId').textContent = cur.text || 'ID မထည့်ရသေးပါ'; $('ktInput').value = it.note || '';
    $('ktName').textContent = it.name || 'ပစ္စည်း'; $('ktCust').textContent = it.buyer || '-'; $('ktSrc').textContent = it.source || '-';
    const q = parseInt(it.qty) || 1, pr = parseFloat(it.price) || 0, fee = parseFloat(it.fee) || 0;
    $('ktCost').textContent = (pr > 0 ? Math.round(pr * q) : 0).toLocaleString() + ' Ks'; $('ktFee').textContent = Math.round(fee).toLocaleString() + ' Ks'; $('ktFee2Row').style.display = gate ? '' : 'none'; $('ktFee2').textContent = Math.round(parseFloat(it.gateFee) || 0).toLocaleString() + ' Ks';
    $('ktQty').textContent = q + ' ခု'; $('ktKg').textContent = (parseFloat(it.kg) || 0) + ' Kg';
    $('ktAv').innerHTML = ico(m); $('ktCName').textContent = ex ? courier(ex) : (it.source || 'China'); $('ktCRole').textContent = LBL[m] + ' • ' + pill;
  }

  function renderGate() {
    const g = gates().find(x => x.id === cur.id); if (!g) return;
    cur.mode = 'gate';
    const stage = stageGate(g), m = tOf(g), n = (g.items || []).length;
    $('ktGridItem').style.display = 'none'; $('ktGridGate').style.display = ''; $('ktItems').style.display = ''; $('ktItemOnly').style.display = 'none'; $('ktManage').style.display = '';
    common(stage, m, 'လားရှိုး → ရန်ကုန် ပို့ဆောင်ပုံ');
    cur.text = g.gate;
    $('ktCour').textContent = GLBL[m] + ' • လားရှိုး → ရန်ကုန်'; $('ktId').textContent = g.gate;
    $('ktStatus').textContent = g.checked ? 'ရန်ကုန်ရောက်ပြီ' : (g.checking ? 'စစ်နေဆဲ' : GLBL[m] + 'တင်ပြီး • လမ်းမှာ');
    $('ktCreated').textContent = 'Sent, ' + (g.date || ''); $('ktDest').textContent = '';
    $('ktGType').textContent = GLBL[m]; $('ktGName').textContent = g.gate; $('ktGCount').textContent = n + ' မျိုး';
    $('ktGKg').textContent = gKgS(g).toFixed(2) + ' Kg'; const fr = gFeeS(g), kgS = gKgS(g); const fi = $('ktGFreight'); fi.value = fr || ''; $('ktGRate').textContent = fr > 0 && kgS > 0 ? '≈ ' + Math.round(fr / kgS).toLocaleString() + ' Ks' : '-';
    fi.onchange = () => { const v = Math.max(0, parseFloat(fi.value) || 0); g.freight = v; g.totalFee = v; try { gRecalc(g); } catch (e) {} persist(); renderGate(); toast('✅ တန်ဆာခကို Kg % အလိုက် ခွဲတွက်ပြီးပါပြီ'); }; $('ktGNote').textContent = g.note || '-';
    const grp = new Map(); (g.items || []).forEach(i => { const k = (i.buyer || '').trim() || '(နာမည်မရှိ)'; if (!grp.has(k)) grp.set(k, []); grp.get(k).push(i); });
    let ih = `<div class="kt-sec" style="margin-top:14px">ပါဝင်တဲ့ ပစ္စည်းများ (${n}) • Customer ${grp.size} ဦး</div>`;
    grp.forEach((arr, k) => {
      const gk = arr.reduce((a, i) => a + (parseFloat(i.kg) || 0), 0), gf = arr.reduce((a, i) => a + (parseFloat(i.gateFee) || 0), 0);
      ih += `<div class="kt-gh"><div>${esc(k)} <span>• ${arr.length} order • ${gk.toFixed(2)} Kg</span></div><div>${Math.round(gf).toLocaleString()} Ks</div></div>`;
      ih += arr.map(i => `<div class="kt-it" data-id="${esc(i.id)}"><div style="min-width:0"><div class="kt-val">${i.got ? '✅ ' : ''}${esc(i.name)} <span class="kt-or">x${esc(i.qty)}</span></div><div class="kt-lab">${parseFloat(i.kg) || 0} Kg${i.note ? ' • ' + esc(i.note) : ''}</div></div><div style="display:flex;align-items:center;flex-shrink:0"><div class="kt-val kt-or">${Math.round(parseFloat(i.gateFee) || 0).toLocaleString()} Ks</div><button type="button" class="kt-pen" data-eo="${esc(i.id)}"><i class="fa-solid fa-pen"></i></button></div></div>`).join('');
    });
    $('ktItems').innerHTML = ih;
    $('ktItems').querySelectorAll('[data-eo]').forEach(b => b.onclick = (ev) => { ev.stopPropagation(); if (window.lyEditOrder) window.lyEditOrder(b.dataset.eo); });
    $('ktItems').querySelectorAll('.kt-it').forEach(r => r.onclick = () => window.openKismetTrackModal(r.dataset.id));
  }

  function open() { const w = $('ktSheetWrap') || buildSheet(); w.classList.remove('kt-hidden'); const s = $('ktSheet'); if (s) s.scrollTop = 0; }
  window.openKismetTrackModal = function (itemId) { if (!findItem(itemId)) return toast('ပစ္စည်း မတွေ့ပါ'); cur.id = itemId; haptic(); open(); render(); };
  window.openKismetGateTrack = function (gid) { if (!gates().some(g => g.id === gid)) return; cur.id = gid; haptic(); open(); renderGate(); };
  window.closeKismetTrackModal = closeTrack;
  window.ktRerender = function () { const w = $('ktSheetWrap'); if (!w || w.classList.contains('kt-hidden')) return; cur.mode === 'gate' ? renderGate() : render(); };

  /* ---------- 7. Tap an item card => open tracking ---------- */
  const HOSTS = '#orderListContainer,#lashioCheckList,#kgCalculatorItemList,#gateDetailModal';
  document.addEventListener('click', (e) => {
    try {
      if (e.target.closest('button,input,select,textarea,a,label,#ktSheetWrap,.kt-pc')) return;
      const host = e.target.closest(HOSTS); if (!host) return;
      let el = e.target;
      while (el && el !== host) {
        const ids = new Set((el.innerHTML || '').match(/ORD-[A-Za-z0-9-]+/g) || []);
        if (ids.size > 1) return;
        if (ids.size === 1) { window.openKismetTrackModal([...ids][0]); return; }
        el = el.parentElement;
      }
    } catch (err) {}
  }, false);

  window.KISMET_ANIMATE_DONUT = function () {};
  placePanel();
})();
