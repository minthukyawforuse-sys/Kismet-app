/* KISMET tracking add-on v3 */
(function () {
  if (window.__ktLoaded) return; window.__ktLoaded = true;
  const $ = (id) => document.getElementById(id);
  const cap = (n) => (window.Capacitor && window.Capacitor.Plugins) ? window.Capacitor.Plugins[n] : null;
  const toast = (m) => { try { if (typeof showToast === 'function') showToast(m); } catch (e) {} };
  const haptic = () => { try { const H = cap('Haptics'); if (H && H.impact) H.impact({ style: 'LIGHT' }); else if (navigator.vibrate) navigator.vibrate(25); } catch (e) {} };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---------- 1. Gallery / file saving ---------- */
  const blobToB64 = (b) => new Promise((res, rej) => { const f = new FileReader(); f.onloadend = () => res(f.result); f.onerror = rej; f.readAsDataURL(b); });
  function interceptSave(a) {
    try {
      const saver = cap('KismetSaver'); if (!saver || !a) return false;
      const href = a.href || a.getAttribute('href') || '';
      const dl = a.download || a.getAttribute('download') || ('KISMET_' + Date.now() + '.png');
      if (!href) return false;
      const okImg = () => { toast('✅ Gallery (Pictures/KISMET) ထဲ သိမ်းပြီးပါပြီ'); haptic(); };
      const bad = (e) => toast('⚠️ Save Error: ' + (e && e.message ? e.message : 'Failed'));
      if (href.startsWith('data:image/')) { saver.saveImage({ base64: href, filename: dl }).then(okImg).catch(bad); return true; }
      if (href.startsWith('blob:')) {
        fetch(href).then(r => r.blob()).then(b => {
          if ((b.type && b.type.startsWith('image/')) || /\.(png|jpg|jpeg|webp)$/i.test(dl))
            return blobToB64(b).then(u => saver.saveImage({ base64: u, filename: dl })).then(okImg);
          return b.text().then(t => saver.saveFile({ text: t, filename: dl, mime: b.type || 'text/csv' }))
            .then(() => { toast('✅ Download/KISMET ထဲ သိမ်းပြီးပါပြီ'); haptic(); });
        }).catch(bad);
        return true;
      }
    } catch (e) {}
    return false;
  }
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () { if (interceptSave(this)) return; return origClick.apply(this, arguments); };

  /* ---------- 2. Modern vehicle artwork ---------- */
  const BIG = { Land: '<img src="./img/Land.png" alt="">', Air: '<img src="./img/Air.png" alt="">', Post: '<img src="./img/Post.png" alt="">' };
  const BOXIMG = '<img src="./img/Box.png" alt="" style="width:26px;height:26px;object-fit:contain;vertical-align:middle;margin-right:6px">';
  const FAI = { Air: 'fa-plane', Land: 'fa-truck-fast', Post: 'fa-envelope' };
  const FAG = { Air: '\uf072', Land: '\uf48b', Post: '\uf0e0' };
  const LBL = { Air: 'လေယာဉ်', Land: 'ကား', Post: 'စာတိုက်' };
  const GLBL = { Air: 'လေယာဉ်', Land: 'ကားဂိတ်', Post: 'စာတိုက်' };
  const EMO = { Air: '✈️', Land: '🚚', Post: '📮' };
  const ico = (m) => `<i class="fa-solid ${FAI[m] || FAI.Air}"></i>`;

  /* ---------- 3. Data helpers ---------- */
  const allItems = () => {
    try { if (typeof allRouteRecords !== 'undefined') return Object.values(allRouteRecords).reduce((a, l) => a.concat(Array.isArray(l) ? l : []), []); } catch (e) {}
    return [];
  };
  const gates = () => { try { return typeof gateShipments !== 'undefined' ? gateShipments : []; } catch (e) { return []; } };
  function findItem(id) {
    const d = allItems().find(x => x && x.id === id); let gate = null;
    for (const g of gates()) { const it = (g.items || []).find(x => x && x.id === id); if (it) { gate = g; if (!d) return { item: it, gate }; break; } }
    return d ? { item: d, gate } : null;
  }
  const mOf = (it) => (it && FAI[it.method]) ? it.method : 'Air';
  const tOf = (g) => (g && FAI[g.transport]) ? g.transport : 'Land';
  const stageItem = (it, g) => g && g.checked ? 4 : g ? 3 : it && it.arrived ? 2 : 1;
  const stageGate = (g) => g.checked ? 4 : 3;
  const STATE = ['', 'လမ်းမှာ', 'လားရှိုး', 'လမ်းမှာ', 'ရောက်ပြီ'];
  function trackId(t) { const m = String(t || '').trim().match(/\b([A-Za-z]{1,4}\d{6,22}|\d{8,22})\b/); return m ? m[1].toUpperCase() : ''; }
  function courier(id) {
    if (!id) return 'China Courier';
    if (/^JT\d{8,}$/.test(id)) return 'J&T Express (极兔速递)';
    if (/^SF\d{8,}$/.test(id)) return 'SF Express (顺丰速运)';
    if (/^YT\d{8,}$/.test(id)) return 'YTO Express (圆通速递)';
    if (/^(75|78|73|54)\d{8,}$/.test(id)) return 'ZTO Express (中通快递)';
    if (/^77\d{9,}$/.test(id)) return 'STO Express (申通快递)';
    if (/^(43|46|31)\d{9,}$/.test(id)) return 'Yunda Express (韵达快递)';
    return 'China Courier';
  }
  const fmtDate = (ms) => new Date(ms).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const gKgS = (g) => (g.items || []).reduce((a, i) => a + (parseFloat(i.kg) || 0), 0);
  const gFeeS = (g) => parseFloat(g.totalFee) || (g.items || []).reduce((a, i) => a + (parseFloat(i.fee) || 0), 0);

  /* ---------- 4. Live-activity pills (panel on Dashboard / Route page) ---------- */
  let pFilter = 'All', pAll = false, lastSig = '';
  function pillHTML(o) {
    return `<div class="kt-pc kt-s${o.stage}" data-k="${o.kind}" data-id="${esc(o.id)}">
      <div class="kt-pc-top"><div class="kt-pc-ic">${ico(o.m)}</div>
        <div class="kt-pc-nm"><div class="kt-pc-t">${esc(o.name)}</div><div class="kt-pc-s">${esc(o.sub)}</div></div>
        <span class="kt-pc-st">${STATE[o.stage]}</span></div>
      <div class="kt-bar"><div class="kt-bar-bg"></div><div class="kt-bar-fill"></div><i class="kt-bar-dot" style="left:6px"></i><i class="kt-bar-dot" style="left:calc(50% - 2px)"></i><i class="kt-bar-dot" style="right:6px"></i><div class="kt-bar-mk"></div></div>
      <div class="kt-bar-lb"><span>တရုတ်</span><span>လားရှိုး</span><span>ရန်ကုန်</span></div></div>`;
  }
  function pillData() {
    const out = [];
    allItems().forEach(it => { const id = trackId(it.note); out.push({ kind: 'item', id: it.id, m: mOf(it), stage: stageItem(it, null), name: it.name || 'ပစ္စည်း', sub: (id ? id + ' • ' : (it.buyer ? it.buyer + ' • ' : '')) + (parseFloat(it.kg) || 0) + ' Kg' }); });
    gates().forEach(g => out.push({ kind: 'gate', id: g.id, m: tOf(g), stage: stageGate(g), name: g.gate, sub: GLBL[tOf(g)] + ' • ' + (g.items || []).length + ' မျိုး • ' + gKgS(g).toFixed(1) + ' Kg' }));
    out.sort((a, b) => (a.stage === 4) - (b.stage === 4));
    return out.filter(o => pFilter === 'All' || o.m === pFilter);
  }
  function buildPanel() {
    const p = document.createElement('div'); p.id = 'kismetRouteAnimPanel';
    p.addEventListener('click', (e) => {
      const chip = e.target.closest('[data-f]'); if (chip) { pFilter = chip.dataset.f; pAll = false; lastSig = ''; haptic(); return refreshPanel(); }
      if (e.target.closest('.kt-more')) { pAll = !pAll; lastSig = ''; return refreshPanel(); }
      const pc = e.target.closest('.kt-pc'); if (!pc || !pc.dataset.id) return;
      if (pc.dataset.k === 'gate') window.openKismetGateTrack(pc.dataset.id); else window.openKismetTrackModal(pc.dataset.id);
    });
    return p;
  }
  function refreshPanel() {
    const p = $('kismetRouteAnimPanel'); if (!p) return;
    const d = pillData(), sig = pFilter + pAll + d.map(o => o.kind + o.id + o.stage + o.name + o.sub + o.m).join('|');
    if (sig === lastSig) return; lastSig = sig;
    const show = pAll ? d : d.slice(0, 3);
    p.innerHTML = `<div class="kt-row"><div style="display:flex;align-items:center;gap:6px;min-width:0"><span style="width:8px;height:8px;border-radius:99px;background:#f26419;display:inline-block"></span><span style="font-size:12px;font-weight:800">တရုတ် - လားရှိုး - ရန်ကုန်</span></div>
      <div class="kt-tabs">${[['All', 'အားလုံး'], ['Air', ico('Air')], ['Land', ico('Land')], ['Post', ico('Post')]].map(([k, l]) => `<button type="button" data-f="${k}" class="kt-tab${pFilter === k ? ' on' : ''}">${l}</button>`).join('')}</div></div>
      ${show.length ? show.map(pillHTML).join('') : pillHTML({ kind: 'none', id: '', m: pFilter === 'All' ? 'Air' : pFilter, stage: 1, name: 'ပစ္စည်း မရှိသေးပါ', sub: 'ထည့်လိုက်ရင် ဒီမှာ Track ပေါ်မယ်' }).replace(/<div class="kt-pc-ic">.*?<\/div>/, '<div class="kt-pc-ic" style="background:none;box-shadow:none">' + BOXIMG.replace('26px', '34px').replace('26px', '34px').replace('margin-right:6px', '') + '</div>')}
      ${d.length > 3 ? `<button type="button" class="kt-more">${pAll ? 'လျှော့ပြရန်' : 'အားလုံးကြည့်ရန် (' + d.length + ')'}</button>` : ''}`;
  }
  function placePanel() {
    let p = $('kismetRouteAnimPanel');
    const mode = (typeof currentMainMode !== 'undefined') ? currentMainMode : 'dashboard';
    if (!p) { p = buildPanel(); lastSig = ''; }
    if (mode === 'shop') { p.classList.add('kt-hidden'); return; }
    p.classList.remove('kt-hidden');
    const host = mode === 'route' ? $('section-route') : $('page-dashboard');
    if (!host) return;
    if (p.parentElement !== host) { host.insertBefore(p, mode === 'route' ? host.firstChild : (host.firstElementChild ? host.firstElementChild.nextSibling : null)); lastSig = ''; }
    refreshPanel();
  }
  setInterval(() => { try { placePanel(); } catch (e) {} }, 900);

  /* ---------- 5. Compact gate cards (Lashio -> Yangon list) ---------- */
  function gateCard(g) {
    const m = tOf(g), st = stageGate(g), checking = !g.checked && (g.checking || (g.items || []).some(i => i.got));
    const got = (g.items || []).filter(i => i.got).length, n = (g.items || []).length;
    const done = [true, g.checked || checking, !!g.checked];
    const pos = g.checked ? null : (checking ? 75 : 25);
    const txt = g.checked ? 'ရန်ကုန်ရောက်ပြီ ✅' : checking ? `စစ်နေဆဲ ${got}/${n}` : GLBL[m] + 'တင်ပြီး';
    return `<div class="kt-ship${g.checked ? ' ok' : ''}" data-gid="${esc(g.id)}">
      <div class="kt-ship-main">
        <div class="kt-ship-top"><div class="kt-ship-ic">${ico(m)}</div><div style="min-width:0"><div class="kt-ship-id">${esc(g.gate)}</div><div class="kt-ship-sub">${n} မျိုး • ${gKgS(g).toFixed(2)} Kg • ${Math.round(gFeeS(g)).toLocaleString()} Ks</div></div></div>
        <span class="kt-ship-st">${txt}</span>
        <div class="kt-st-track"><div class="kt-st-fill" style="width:calc(${g.checked ? 100 : (checking ? 50 : 0)}% - 20px)"></div>
          ${done.map(d => `<span class="kt-st-n${d ? ' d' : ''}"><i class="fa-solid fa-check"></i></span>`).join('')}
          ${pos ? `<span class="kt-st-v" style="left:${pos}%">${ico(m)}</span>` : ''}</div>
        <div class="kt-ship-dates"><div>${esc(g.date || '')}<b>လားရှိုး</b></div><div style="text-align:right">${GLBL[m]}<b>ရန်ကုန်</b></div></div>
      </div>
      <div class="kt-ship-art">${BIG[m]}</div></div>`;
  }
  const origRGL = window.renderGateLists;
  window.renderGateLists = function () {
    try {
      const g = gates();
      const html = g.length === 0 ? `<div class="deep-black-box p-2.5 rounded-xl text-center text-[11px] text-neutral-500">တင်ပို့ထားသော စာရင်း မရှိသေးပါ</div>` : g.map(gateCard).join('');
      ['dashGateList', 'page3GateList'].forEach(id => { const el = $(id); if (el) el.innerHTML = html; });
      ['dashGateBadge', 'page3GateBadge'].forEach(id => { const el = $(id); if (el) el.innerText = `${g.length} ခု`; });
    } catch (e) { if (origRGL) origRGL(); }
  };
  document.addEventListener('click', (e) => {
    const c = e.target.closest('.kt-ship'); if (!c || e.target.closest('#ktSheetWrap')) return;
    window.openKismetGateTrack(c.dataset.gid);
  });
  try { window.renderGateLists(); } catch (e) {}

  /* ---------- 6. Location Tracking sheet ---------- */
  const PATH = 'M 326 56 L 258 56 Q 244 56 244 70 L 244 100 Q 244 114 230 114 L 154 114 Q 140 114 140 128 L 140 154 Q 140 168 126 168 L 82 168';
  let cur = { mode: 'item', id: null, text: '', raf: 0 };

  function buildSheet() {
    const w = document.createElement('div'); w.id = 'ktSheetWrap'; w.className = 'kt-hidden';
    w.addEventListener('click', (e) => { if (e.target === w) closeTrack(); });
    w.innerHTML = `
    <div class="kt-sheet" id="ktSheet">
      <div class="kt-map">
        <svg viewBox="0 0 400 215" style="width:100%;height:100%;display:block">
          <defs><pattern id="ktGrid" width="22" height="22" patternUnits="userSpaceOnUse"><path d="M22 0H0V22" fill="none" stroke="rgba(255,255,255,.05)" stroke-width="1"/></pattern></defs>
          <rect width="400" height="215" fill="url(#ktGrid)"/>
          <path d="M0 85Q100 68 180 108T345 82L400 70" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="1.2"/>
          <path d="M115 0Q150 75 130 138T160 215" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="1.2"/>
          <path d="${PATH}" fill="none" stroke="rgba(255,255,255,.28)" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="6 6" class="kt-flow"/>
          <path id="ktSeg" d="${PATH}" fill="none" stroke="#f26419" stroke-width="4.5" stroke-linecap="round"/>
          <path id="ktAct" d="${PATH}" fill="none" stroke="#f26419" stroke-width="4.5" stroke-linecap="round"/>
          <circle cx="326" cy="56" r="14" fill="#f26419" fill-opacity=".24"/><circle cx="326" cy="56" r="6" fill="#f26419" stroke="#fff" stroke-width="2.5"/>
          <text x="326" y="79" text-anchor="middle" fill="#fff" font-size="10" font-weight="800">တရုတ်</text>
          <circle id="ktLsh" cx="192" cy="114" r="5.5" fill="#0a0a0c" stroke="#f26419" stroke-width="2.5"/>
          <text x="192" y="133" text-anchor="middle" fill="#fdba74" font-size="10" font-weight="800">လားရှိုး</text>
          <circle cx="82" cy="168" r="13" fill="#0a0a0c" stroke="#f26419" stroke-width="2"/><text x="82" y="172" text-anchor="middle" fill="#f26419" font-size="10" font-weight="900">▲</text>
          <text x="82" y="194" text-anchor="middle" fill="#fff" font-size="10" font-weight="800">ရန်ကုန်</text>
          <g id="ktMark" transform="translate(326,56)"><circle id="ktRingC" class="kt-ring" r="9" fill="#f26419"/><circle id="ktHalo" r="13" fill="#f26419" fill-opacity=".3"/><circle id="ktDisc" r="11" fill="#f26419" stroke="#fff" stroke-width="2"/><text id="ktMarkEmo" y="4" text-anchor="middle" font-size="10" fill="#fff" font-family="'Font Awesome 6 Free'" font-weight="900"></text></g>
        </svg>
        <div class="kt-top">
          <button type="button" class="kt-cbtn" id="ktClose"><i class="fa-solid fa-arrow-left"></i></button>
          <div class="kt-title">Location Tracking</div>
          <div style="display:flex;gap:6px"><button type="button" class="kt-cbtn kt-or" id="ktCopy"><i class="fa-regular fa-copy"></i></button><button type="button" class="kt-cbtn kt-or" id="ktShot"><i class="fa-solid fa-image"></i></button></div>
        </div>
      </div>
      <div class="kt-body">
        <div class="kt-grab"></div>
        <div class="kt-row" style="align-items:flex-start">
          <div style="min-width:0"><div class="kt-lab" id="ktCour">Tracking Id:</div><div id="ktId" style="font-size:20px;font-weight:800;font-family:monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.5">-</div></div>
          <div style="text-align:right;flex-shrink:0"><div class="kt-lab">Status</div><span class="kt-pill" id="ktStatus">Transit</span></div>
        </div>
        <div class="kt-steps"><span class="kt-dot" id="ktD1"><i class="fa-solid fa-check"></i></span><span class="kt-line" id="ktL1"></span><span class="kt-dot" id="ktD2"><i class="fa-solid fa-check"></i></span><span class="kt-line" id="ktL2"></span><span class="kt-dot" id="ktD3"><i class="fa-solid fa-check"></i></span></div>
        <div class="kt-dates"><div><div class="kt-lab" id="ktCreated">Created</div><div class="kt-val" id="ktFrom">တရုတ်</div></div><div style="text-align:center"><div class="kt-lab">Transit Hub</div><div class="kt-val kt-or">လားရှိုး</div></div><div style="text-align:right"><div class="kt-lab" id="ktDestLab">Destination</div><div class="kt-val" id="ktDest">ရန်ကုန်</div></div></div>
        <div class="kt-info">
          <div class="kt-grid" id="ktGridItem">
            <div style="grid-column:1/3"><div class="kt-lab">ပစ္စည်း (Item)</div><div class="kt-val" id="ktName" style="white-space:normal">-</div></div>
            <div><div class="kt-lab">Customer</div><div class="kt-val" id="ktCust">-</div></div>
            <div><div class="kt-lab">မှာတဲ့နေရာ</div><div class="kt-val" id="ktSrc">-</div></div>
            <div><div class="kt-lab">Order Cost</div><div class="kt-val kt-or" id="ktCost">0 Ks</div></div>
            <div><div class="kt-lab">တန်ဆာခ</div><div class="kt-val kt-or" id="ktFee">0 Ks</div></div>
            <div><div class="kt-lab">Quantity</div><div class="kt-val" id="ktQty">1</div></div>
            <div><div class="kt-lab">Weight</div><div class="kt-val" id="ktKg">0 Kg</div></div>
          </div>
          <div class="kt-grid" id="ktGridGate" style="display:none">
            <div style="grid-column:1/3"><div class="kt-lab" id="ktGTypeLab">ကားဂိတ်</div><div class="kt-val" id="ktGName" style="white-space:normal">-</div></div>
            <div><div class="kt-lab">ပစ္စည်း</div><div class="kt-val" id="ktGCount">0</div></div>
            <div><div class="kt-lab">စုစုပေါင်း Weight</div><div class="kt-val" id="ktGKg">0 Kg</div></div>
            <div><div class="kt-lab">စုစုပေါင်း တန်ဆာခ</div><div class="kt-val kt-or" id="ktGFee">0 Ks</div></div>
            <div><div class="kt-lab">မှတ်ချက်</div><div class="kt-val" id="ktGNote">-</div></div>
          </div>
          <div class="kt-vstage"><div id="ktBig"></div><span id="ktBigLbl" class="kt-or"></span></div>
        </div>
        <div class="kt-lab" id="ktLegLab" style="margin-top:14px;margin-bottom:6px"></div><div class="kt-seg" id="ktChoose"></div>
        <div class="kt-items" id="ktItems" style="display:none"></div>
        <div id="ktItemOnly">
          <div class="kt-courier">
            <div style="display:flex;align-items:center;gap:10px;min-width:0"><div class="kt-av" id="ktAv"></div><div style="min-width:0"><div class="kt-val" id="ktCName">Courier</div><div class="kt-lab" id="ktCRole">Courier</div></div></div>
            <div style="display:flex;gap:7px"><button type="button" class="kt-rb" style="background:linear-gradient(135deg,#f26419,#c4420a);color:#fff" id="kt17"><i class="fa-solid fa-magnifying-glass-location"></i></button><button type="button" class="kt-rb" style="background:#fff;color:#0a0a0c" id="ktKd"><i class="fa-solid fa-globe"></i></button></div>
          </div>
          <div class="kt-edit"><input id="ktInput" placeholder="Tracking ID ထည့်/ပြင်ရန်..."><button type="button" id="ktSave">သိမ်း</button></div>
        </div>
        <button type="button" class="kt-manage" id="ktManage" style="display:none"><i class="fa-solid fa-clipboard-check"></i> စစ်ဆေးရန် / ပြင်ရန်</button>
      </div>
    </div>`;
    document.body.appendChild(w);
    $('ktClose').onclick = closeTrack;
    $('ktCopy').onclick = () => { if (!cur.text) return toast('ကူးစရာ မရှိသေးပါ'); try { copyTextToClipboard(cur.text); } catch (e) { toast(cur.text); } };
    $('ktSave').onclick = saveId; $('kt17').onclick = () => ext('17track'); $('ktKd').onclick = () => ext('kuaidi'); $('ktShot').onclick = shot;
    $('ktManage').onclick = () => { const id = cur.id; closeTrack(); try { openGateDetail(id); } catch (e) {} };
    return w;
  }
  function closeTrack() { const w = $('ktSheetWrap'); if (w) w.classList.add('kt-hidden'); cancelAnimationFrame(cur.raf); lastSig = ''; try { window.renderGateLists(); } catch (e) {} }
  function ext(p) {
    const id = trackId($('ktInput').value) || cur.text;
    if (!id) return toast('Tracking ID အရင်ထည့်ပါ');
    window.open(p === 'kuaidi' ? 'https://m.kuaidi100.com/result.jsp?nu=' + encodeURIComponent(id) : 'https://t.17track.net/en#nums=' + encodeURIComponent(id), '_blank', 'noopener');
  }
  function persist() { try { saveToLocalStorage(); renderAll(); if (typeof renderGateLists === 'function') renderGateLists(); } catch (e) {} lastSig = ''; }
  function saveId() {
    const f = findItem(cur.id); if (!f) return;
    f.item.note = $('ktInput').value.trim(); persist(); render(); toast('✅ Tracking ID သိမ်းဆည်းပြီးပါပြီ');
  }
  function shot() {
    const el = $('ktSheet'); if (!el || typeof html2canvas !== 'function') return toast('html2canvas မရှိပါ');
    toast('ပုံထုတ်နေပါသည်...');
    const ms = el.style.maxHeight, ov = el.style.overflow; el.style.maxHeight = 'none'; el.style.overflow = 'visible';
    html2canvas(el, { scale: 2, backgroundColor: '#0a0a0c', useCORS: true }).then(c => {
      el.style.maxHeight = ms; el.style.overflow = ov;
      const a = document.createElement('a'); a.href = c.toDataURL('image/png'); a.download = 'KISMET_Track_' + Date.now() + '.png'; a.click();
    }).catch(() => { el.style.maxHeight = ms; el.style.overflow = ov; toast('⚠️ ပုံထုတ်မရပါ'); });
  }
  function chooseMethod(m, f, stage) {
    let old = null;
    try {
      if (cur.mode === 'gate') { f.transport = m; }
      else if (stage >= 3 && f.gate) { f.gate.transport = m; }
      else { old = f.item.method || 'Air'; f.item.method = m; }
    } catch (e) {}
    cur.mode === 'gate' ? renderGate() : render();          // update the sheet first
    try { if (old && old !== m && typeof recalculateRouteFees === 'function') { recalculateRouteFees(old); recalculateRouteFees(m); } } catch (e) {}
    persist(); haptic();
    toast('✅ ' + LBL[m] + ' သို့ ပြောင်းပြီးပါပြီ');
  }
  function common(stage, m, legLab) {
    const ok = stage === 4;
    $('ktSheet').classList.toggle('kt-ok', ok);
    $('ktD1').className = 'kt-dot done';
    $('ktD2').className = 'kt-dot ' + (stage >= 2 ? 'done' : 'act'); $('ktL1').className = 'kt-line' + (stage >= 2 ? ' done' : '');
    $('ktD3').className = 'kt-dot ' + (ok ? 'done' : stage >= 2 ? 'act' : ''); $('ktL2').className = 'kt-line' + (ok ? ' done' : '');
    $('ktBig').innerHTML = BIG[m];
    $('ktMarkEmo').textContent = ok ? '\uf00c' : FAG[m];
    $('ktLegLab').textContent = legLab;
  }
  function chooser(m, f, stage) {
    const box = $('ktChoose');
    box.innerHTML = ['Air', 'Land', 'Post'].map(k => `<button type="button" class="kt-segb${k === m ? ' on' : ''}" data-m="${k}">${ico(k)}<span>${LBL[k]}</span></button>`).join('');
    box.querySelectorAll('button').forEach(b => { b.onclick = (ev) => { ev.stopPropagation(); if (b.dataset.m !== m) chooseMethod(b.dataset.m, f, stage); }; });
  }

  function render() {
    const f = findItem(cur.id); if (!f) return;
    cur.mode = 'item';
    const it = f.item, gate = f.gate, stage = stageItem(it, gate), m = stage >= 3 ? tOf(gate) : mOf(it);
    $('ktGridItem').style.display = ''; $('ktGridGate').style.display = 'none'; $('ktItems').style.display = 'none'; $('ktItemOnly').style.display = ''; $('ktManage').style.display = 'none';
    common(stage, m, stage >= 3 ? 'လားရှိုး → ရန်ကုန် ပို့ဆောင်ပုံ' : 'တရုတ် → လားရှိုး ပို့ဆောင်ပုံ');
    const pill = ['', 'တရုတ် → လားရှိုး လမ်းမှာ', 'လားရှိုးရောက်', GLBL[tOf(gate)] + 'တင်ပြီး • လမ်းမှာ', 'ရန်ကုန်ရောက်ပြီ ✅'][stage];
    $('ktStatus').textContent = pill;
    $('ktDest').textContent = gate ? gate.gate : 'ရန်ကုန်'; $('ktDestLab').textContent = gate ? GLBL[tOf(gate)] : 'Destination'; $('ktFrom').textContent = 'တရုတ်';
    const ts = (String(it.id).match(/(\d{13})/) || [])[1]; $('ktCreated').textContent = ts ? 'Created, ' + fmtDate(+ts) : 'Created';
    const ex = trackId(it.note); cur.text = ex || (it.note ? String(it.note).trim() : '');
    $('ktCour').textContent = ex ? courier(ex) : 'Tracking Id:'; $('ktId').textContent = cur.text || 'ID မထည့်ရသေးပါ'; $('ktInput').value = it.note || '';
    $('ktName').innerHTML = BOXIMG + esc(it.name || 'ပစ္စည်း'); $('ktCust').textContent = it.buyer || '-'; $('ktSrc').textContent = it.source || '-';
    const q = parseInt(it.qty) || 1, pr = parseFloat(it.price) || 0, fee = parseFloat(it.fee) || 0;
    $('ktCost').textContent = (pr > 0 ? Math.round(pr * q) : 0).toLocaleString() + ' Ks'; $('ktFee').textContent = Math.round(fee).toLocaleString() + ' Ks';
    $('ktQty').textContent = q + ' ခု'; $('ktKg').textContent = (parseFloat(it.kg) || 0) + ' Kg';
    $('ktBigLbl').textContent = LBL[m] + (stage >= 3 ? ' • လားရှိုး → ရန်ကုန်' : ' • တရုတ် → လားရှိုး');
    $('ktAv').innerHTML = ico(m); $('ktCName').textContent = ex ? courier(ex) : (it.source || 'China') + ' • ' + LBL[m]; $('ktCRole').textContent = LBL[m] + ' • ' + pill;
    chooser(m, f, stage); animateMap(stage);
  }

  function renderGate() {
    const g = gates().find(x => x.id === cur.id); if (!g) return;
    cur.mode = 'gate';
    const stage = stageGate(g), m = tOf(g), n = (g.items || []).length;
    $('ktGridItem').style.display = 'none'; $('ktGridGate').style.display = ''; $('ktItems').style.display = ''; $('ktItemOnly').style.display = 'none'; $('ktManage').style.display = '';
    common(stage, m, 'လားရှိုး → ရန်ကုန် ပို့ဆောင်ပုံ');
    cur.text = g.gate;
    $('ktCour').textContent = GLBL[m] + ' • Lashio → Yangon'; $('ktId').textContent = g.gate;
    $('ktStatus').textContent = g.checked ? 'ရန်ကုန်ရောက်ပြီ ✅' : (g.checking ? 'စစ်နေဆဲ' : GLBL[m] + 'တင်ပြီး • လမ်းမှာ');
    $('ktCreated').textContent = 'Sent, ' + (g.date || ''); $('ktFrom').textContent = 'လားရှိုး'; $('ktDestLab').textContent = 'Destination'; $('ktDest').textContent = 'ရန်ကုန်';
    $('ktGTypeLab').textContent = GLBL[m]; $('ktGName').textContent = g.gate; $('ktGCount').textContent = n + ' မျိုး';
    $('ktGKg').textContent = gKgS(g).toFixed(2) + ' Kg'; $('ktGFee').textContent = Math.round(gFeeS(g)).toLocaleString() + ' Ks'; $('ktGNote').textContent = g.note || '-';
    $('ktBigLbl').textContent = LBL[m] + ' • လားရှိုး → ရန်ကုန်';
    $('ktItems').innerHTML = `<div class="kt-lab" style="font-weight:800;color:#a1a1aa">ပါဝင်တဲ့ ပစ္စည်းများ (${n})</div>` + (g.items || []).map(i =>
      `<div class="kt-it" data-id="${esc(i.id)}"><div style="min-width:0"><div class="kt-val" style="font-size:13px">${i.got ? '✅ ' : ''}${esc(i.name)} <span class="kt-or">(x${esc(i.qty)})</span></div><div class="kt-lab">${esc(i.buyer || '-')}${i.note ? ' • ' + esc(i.note) : ''}</div></div><div style="text-align:right;flex-shrink:0"><div class="kt-val kt-or">${parseFloat(i.kg) || 0} Kg</div><div class="kt-lab">${Math.round(parseFloat(i.fee) || 0).toLocaleString()} Ks</div></div></div>`).join('');
    $('ktItems').querySelectorAll('.kt-it').forEach(r => r.onclick = () => window.openKismetTrackModal(r.dataset.id));
    chooser(m, g, stage); animateMap(stage);
  }
  // chooser needs {gate} shape for items; for gate mode pass the gate itself
  const _chooseMethod = chooseMethod;

  function animateMap(stage) {
    const act = $('ktAct'), seg = $('ktSeg'), mark = $('ktMark'); if (!act || !act.getTotalLength) return;
    const len = act.getTotalLength(), lsh = $('ktLsh'), lx = +lsh.getAttribute('cx'), ly = +lsh.getAttribute('cy');
    let lL = 0, best = 1e9; for (let l = 0; l <= len; l += 2) { const p = act.getPointAtLength(l), d = Math.hypot(p.x - lx, p.y - ly); if (d < best) { best = d; lL = l; } }
    const ok = stage === 4, col = ok ? '#22c55e' : '#f26419';
    [act, seg].forEach(e => { e.style.stroke = col; e.style.strokeDasharray = len + ' ' + len; e.style.filter = 'drop-shadow(0 0 5px ' + (ok ? 'rgba(34,197,94,.9)' : 'rgba(242,100,25,.9)') + ')'; });
    $('ktRingC').setAttribute('fill', col); $('ktHalo').setAttribute('fill', col); $('ktDisc').setAttribute('fill', col);
    const draw = (doneL, a, b) => { act.style.strokeDashoffset = String(len - doneL); seg.style.strokeDasharray = Math.max(0, b - a) + ' ' + (len * 2); seg.style.strokeDashoffset = String(-a); seg.style.opacity = b - a > 0.5 ? 1 : 0; };
    const put = (l) => { const p = act.getPointAtLength(Math.max(0, Math.min(len, l))); mark.setAttribute('transform', 'translate(' + p.x.toFixed(1) + ',' + p.y.toFixed(1) + ')'); };
    cancelAnimationFrame(cur.raf);
    if (stage === 2) { draw(lL, lL, lL); put(lL); return; }
    if (stage === 4) { draw(len, len, len); put(len); return; }
    const s = stage === 1 ? 0 : lL, e = stage === 1 ? lL : len, MOVE = 2600, HOLD = 700, t0 = performance.now();
    const step = (now) => {
      const t = (now - t0) % (MOVE + HOLD), k = Math.min(1, t / MOVE), ez = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2, l = s + (e - s) * ez;
      draw(s, s, l); put(l); cur.raf = requestAnimationFrame(step);
    };
    cur.raf = requestAnimationFrame(step);
  }

  function open() { const w = $('ktSheetWrap') || buildSheet(); w.classList.remove('kt-hidden'); const s = $('ktSheet'); if (s) s.scrollTop = 0; }
  window.openKismetTrackModal = function (itemId) { if (!findItem(itemId)) return toast('ပစ္စည်း မတွေ့ပါ'); cur.id = itemId; haptic(); open(); render(); };
  window.openKismetGateTrack = function (gid) { if (!gates().some(g => g.id === gid)) return; cur.id = gid; haptic(); open(); renderGate(); };
  window.closeKismetTrackModal = closeTrack;

  /* ---------- 7. Tap an item card => open tracking ---------- */
  const HOSTS = '#orderListContainer,#lashioCheckList,#kgCalculatorItemList,#gateDetailModal';
  document.addEventListener('click', (e) => {
    try {
      if (e.target.closest('button,input,select,textarea,a,label,#ktSheetWrap,.kt-ship')) return;
      const host = e.target.closest(HOSTS); if (!host) return;
      let el = e.target;
      while (el && el !== host) {
        const ids = new Set((el.innerHTML || '').match(/ORD-[A-Za-z0-9-]+/g) || []);
        if (ids.size > 1) return;
        if (ids.size === 1) { window.openKismetTrackModal([...ids][0]); return; }
        el = el.parentElement;
      }
    } catch (err) {}
  }, false);

  window.KISMET_ANIMATE_DONUT = function () {};
  placePanel();
})();
