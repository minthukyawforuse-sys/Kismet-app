/* KISMET tracking add-on (replaces kismet-addon-2 / 2b and the old inline map/kg-ring code) */
(function () {
  if (window.__ktLoaded) return; window.__ktLoaded = true;
  const $ = (id) => document.getElementById(id);
  const cap = (n) => (window.Capacitor && window.Capacitor.Plugins) ? window.Capacitor.Plugins[n] : null;
  const toast = (m) => { try { if (typeof showToast === 'function') showToast(m); } catch (e) {} };
  const haptic = () => { try { const H = cap('Haptics'); if (H && H.impact) H.impact({ style: 'LIGHT' }); else if (navigator.vibrate) navigator.vibrate(25); } catch (e) {} };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---------- 1. Gallery / file saving (native KismetSaver plugin, web fallback) ---------- */
  const blobToB64 = (b) => new Promise((res, rej) => { const f = new FileReader(); f.onloadend = () => res(f.result); f.onerror = rej; f.readAsDataURL(b); });
  function interceptSave(a) {
    try {
      const saver = cap('KismetSaver'); if (!saver || !a) return false;
      const href = a.href || a.getAttribute('href') || '';
      const dl = a.download || a.getAttribute('download') || ('KISMET_' + Date.now() + '.png');
      if (!href) return false;
      const okImg = () => { toast('✅ Gallery (Pictures/KISMET) ထဲ သိမ်းပြီးပါပြီ'); haptic(); };
      const bad = (e) => toast('⚠️ Save Error: ' + (e && e.message ? e.message : 'Failed'));
      if (href.startsWith('data:image/')) { saver.saveImage({ base64: href, filename: dl }).then(okImg).catch(bad); return true; }
      if (href.startsWith('blob:')) {
        fetch(href).then(r => r.blob()).then(b => {
          if ((b.type && b.type.startsWith('image/')) || /\.(png|jpg|jpeg|webp)$/i.test(dl))
            return blobToB64(b).then(u => saver.saveImage({ base64: u, filename: dl })).then(okImg);
          return b.text().then(t => saver.saveFile({ text: t, filename: dl, mime: b.type || 'text/csv' }))
            .then(() => { toast('✅ Download/KISMET ထဲ သိမ်းပြီးပါပြီ'); haptic(); });
        }).catch(bad);
        return true;
      }
    } catch (e) {}
    return false;
  }
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () { if (interceptSave(this)) return; return origClick.apply(this, arguments); };

  /* ---------- 2. Vehicle artwork (orange / black) ---------- */
  const G = (id) => `<defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffa062"/><stop offset="1" stop-color="#d9480f"/></linearGradient></defs>`;
  const BIG = {
    Air: `<svg viewBox="0 0 64 64">${G('ktgA')}<path d="M6 36l14-4 12-22c1-2 4-2 5 0l-5 21 17-3c3-.5 6 .5 6 2.5s-3 3-6 3.5l-17 3 5 21c.5 2-2 3-4 1L20 38 6 40z" fill="url(#ktgA)" transform="rotate(-18 32 32)"/><path d="M26 33h20" stroke="#0a0a0c" stroke-width="2" stroke-linecap="round" opacity=".55" transform="rotate(-18 32 32)"/></svg>`,
    Land: `<svg viewBox="0 0 64 64">${G('ktgL')}<rect x="4" y="16" width="34" height="27" rx="4" fill="url(#ktgL)"/><path d="M38 24h12l10 10v9H38z" fill="#fff" opacity=".96"/><path d="M43 27h6l6 7H43z" fill="#0a0a0c" opacity=".85"/><rect x="4" y="38" width="56" height="6" rx="2" fill="#2a2a2e"/><circle cx="17" cy="46" r="7" fill="#0a0a0c" stroke="#ff853b" stroke-width="2.5"/><circle cx="47" cy="46" r="7" fill="#0a0a0c" stroke="#ff853b" stroke-width="2.5"/><circle cx="17" cy="46" r="2.5" fill="#ff853b"/><circle cx="47" cy="46" r="2.5" fill="#ff853b"/><path d="M10 24h22M10 30h14" stroke="#0a0a0c" stroke-width="2.5" stroke-linecap="round" opacity=".4"/></svg>`,
    Post: `<svg viewBox="0 0 64 64">${G('ktgP')}<path d="M6 26L32 8l26 18v4H6z" fill="url(#ktgP)"/><rect x="10" y="30" width="44" height="22" fill="#fff" opacity=".96"/><rect x="6" y="52" width="52" height="5" rx="2" fill="#2a2a2e"/><rect x="14" y="34" width="10" height="18" fill="#0a0a0c" opacity=".85"/><rect x="29" y="35" width="21" height="11" rx="1.5" fill="url(#ktgP)"/><path d="M29 36l10.5 6L50 36" stroke="#fff" stroke-width="1.8" fill="none"/><circle cx="32" cy="19" r="3.4" fill="#0a0a0c" opacity=".8"/></svg>`
  };
  const MINI = {
    Air: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" transform="rotate(90 12 12)"/></svg>',
    Land: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M3 5h11v9H3zM14 8h4l3 3v3h-7z"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/></svg>',
    Post: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M2 5h20v14H2z" opacity=".95"/><path d="M2 6l10 7 10-7" stroke="#c4420a" stroke-width="2" fill="none"/></svg>'
  };
  const LBL = { Air: 'လေယာဉ် (Air)', Land: 'ကား (Land)', Post: 'စာတိုက် (Post)' };
  const EMO = { Air: '✈️', Land: '🚚', Post: '📮' };

  /* ---------- 3. Data helpers ---------- */
  const allItems = () => {
    try { if (typeof allRouteRecords !== 'undefined') return Object.values(allRouteRecords).reduce((a, l) => a.concat(Array.isArray(l) ? l : []), []); } catch (e) {}
    return [];
  };
  function findItem(id) {
    const d = allItems().find(x => x && x.id === id);
    let gate = null;
    try { if (typeof gateShipments !== 'undefined') for (const g of gateShipments) { const it = (g.items || []).find(x => x && x.id === id); if (it) { gate = g; if (!d) return { item: it, gate }; break; } } } catch (e) {}
    return d ? { item: d, gate } : null;
  }
  function trackId(t) { const m = String(t || '').trim().match(/\b([A-Za-z]{1,4}\d{6,22}|\d{8,22})\b/); return m ? m[1].toUpperCase() : ''; }
  function courier(id) {
    if (!id) return 'Tracking ID မထည့်ရသေးပါ';
    if (/^JT\d{8,}$/.test(id)) return 'J&T Express (极兔速递)';
    if (/^SF\d{8,}$/.test(id)) return 'SF Express (顺丰速运)';
    if (/^YT\d{8,}$/.test(id)) return 'YTO Express (圆通速递)';
    if (/^(75|78|73|54)\d{8,}$/.test(id)) return 'ZTO Express (中通快递)';
    if (/^77\d{9,}$/.test(id)) return 'STO Express (申通快递)';
    if (/^(43|46|31)\d{9,}$/.test(id)) return 'Yunda Express (韵达快递)';
    return 'China Courier';
  }
  const fmtDate = (ms) => new Date(ms).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

  /* ---------- 4. Dashboard / route panel : China - Lashio - Yangon loop (no Kg % ring) ---------- */
  let panelMethod = 'Air';
  function buildPanel() {
    const p = document.createElement('div'); p.id = 'kismetRouteAnimPanel';
    p.innerHTML = `
      <div class="kt-row">
        <div style="display:flex;align-items:center;gap:6px;min-width:0"><span style="width:8px;height:8px;border-radius:99px;background:#f26419;display:inline-block"></span><span style="font-size:12px;font-weight:800">တရုတ် - လားရှိုး - ရန်ကုန်</span></div>
        <div class="kt-tabs">${['Air', 'Land', 'Post'].map(m => `<button type="button" class="kt-tab${m === panelMethod ? ' on' : ''}" data-m="${m}">${EMO[m]} ${m}</button>`).join('')}</div>
      </div>
      <div class="kt-box">
        <div class="kt-rail-wrap"><div class="kt-rail"></div><div class="kt-trail"></div><span class="kt-node kt-n1"></span><span class="kt-node kt-n2"></span><span class="kt-node kt-n3"></span><div class="kt-veh" id="ktPanelVeh">${MINI[panelMethod]}</div></div>
        <div class="kt-lbls"><span style="color:#d4d4d8">တရုတ်</span><span style="color:#fb923c">လားရှိုး</span><span>ရန်ကုန်</span></div>
        <div class="kt-row" style="margin-top:8px"><span id="ktPanelStat" style="font-size:10px;color:#a3a3a3"></span><span style="font-size:10px;color:#71717a">ပစ္စည်းကို နှိပ်ရင် Track ပေါ်မယ်</span></div>
      </div>`;
    p.querySelectorAll('.kt-tab').forEach(b => b.addEventListener('click', () => { panelMethod = b.dataset.m; haptic(); refreshPanel(true); }));
    return p;
  }
  function refreshPanel(replay) {
    const p = $('kismetRouteAnimPanel'); if (!p) return;
    p.querySelectorAll('.kt-tab').forEach(b => b.classList.toggle('on', b.dataset.m === panelMethod));
    const v = $('ktPanelVeh'); if (v) v.innerHTML = MINI[panelMethod];
    if (replay) { const t = p.querySelector('.kt-trail'); [v, t].forEach(e => { if (e) { e.style.animation = 'none'; void e.offsetWidth; e.style.animation = ''; } }); }
    const sub = allItems().filter(i => (i.method || 'Air') === panelMethod);
    const kg = sub.reduce((s, i) => s + (parseFloat(i.kg) || 0), 0);
    const st = $('ktPanelStat'); if (st) st.textContent = `${LBL[panelMethod]} • ${sub.length} မျိုး • ${kg.toFixed(1)} Kg`;
  }
  function placePanel() {
    let p = $('kismetRouteAnimPanel');
    const mode = (typeof currentMainMode !== 'undefined') ? currentMainMode : 'dashboard';
    if (!p) { p = buildPanel(); }
    if (mode === 'shop') { p.classList.add('kt-hidden'); return; }
    p.classList.remove('kt-hidden');
    const host = mode === 'route' ? $('section-route') : $('page-dashboard');
    if (!host) return;
    if (p.parentElement !== host) { host.insertBefore(p, mode === 'route' ? host.firstChild : (host.firstElementChild ? host.firstElementChild.nextSibling : null)); refreshPanel(true); }
  }
  let lastSig = '';
  setInterval(() => {
    try { placePanel(); const sig = panelMethod + '|' + allItems().map(i => (i.method || 'Air') + (i.kg || 0)).join(','); if (sig !== lastSig) { lastSig = sig; refreshPanel(false); } } catch (e) {}
  }, 900);

  /* ---------- 5. Location Tracking sheet ---------- */
  const PATH = 'M 326 56 L 258 56 Q 244 56 244 70 L 244 100 Q 244 114 230 114 L 154 114 Q 140 114 140 128 L 140 154 Q 140 168 126 168 L 82 168';
  let cur = { id: null, text: '', raf: 0 };

  function buildSheet() {
    const w = document.createElement('div'); w.id = 'ktSheetWrap'; w.className = 'kt-hidden';
    w.addEventListener('click', (e) => { if (e.target === w) closeTrack(); });
    w.innerHTML = `
    <div class="kt-sheet" id="ktSheet">
      <div class="kt-map">
        <svg viewBox="0 0 400 215" style="width:100%;height:100%;display:block">
          <defs><pattern id="ktGrid" width="22" height="22" patternUnits="userSpaceOnUse"><path d="M22 0H0V22" fill="none" stroke="rgba(255,255,255,.05)" stroke-width="1"/></pattern></defs>
          <rect width="400" height="215" fill="url(#ktGrid)"/>
          <path d="M0 85Q100 68 180 108T345 82L400 70" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="1.2"/>
          <path d="M115 0Q150 75 130 138T160 215" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="1.2"/>
          <path id="ktBase" d="${PATH}" fill="none" stroke="rgba(255,255,255,.28)" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="6 6" class="kt-flow"/>
          <path id="ktAct" class="kt-active-path" d="${PATH}" fill="none" stroke="#f26419" stroke-width="4.5" stroke-linecap="round" style="filter:drop-shadow(0 0 5px rgba(242,100,25,.9))"/>
          <circle cx="326" cy="56" r="14" fill="#f26419" fill-opacity=".24"/><circle cx="326" cy="56" r="6" fill="#f26419" stroke="#fff" stroke-width="2.5"/>
          <text x="326" y="79" text-anchor="middle" fill="#fff" font-size="10" font-weight="800">တရုတ်</text>
          <circle id="ktLsh" cx="192" cy="114" r="5.5" fill="#0a0a0c" stroke="#f26419" stroke-width="2.5"/>
          <text x="192" y="133" text-anchor="middle" fill="#fdba74" font-size="10" font-weight="800">လားရှိုး</text>
          <circle cx="82" cy="168" r="13" fill="#0a0a0c" stroke="#f26419" stroke-width="2"/><text x="82" y="172" text-anchor="middle" fill="#f26419" font-size="10" font-weight="900">▲</text>
          <text x="82" y="194" text-anchor="middle" fill="#fff" font-size="10" font-weight="800">ရန်ကုန်</text>
          <g id="ktMark" transform="translate(326,56)"><circle class="kt-ring" r="9" fill="#f26419"/><circle r="12" fill="#f26419" fill-opacity=".3"/><circle r="10" fill="#0a0a0c" stroke="#f26419" stroke-width="2"/><text id="ktMarkEmo" y="4" text-anchor="middle" font-size="11"></text></g>
        </svg>
        <div class="kt-top">
          <button type="button" class="kt-cbtn" id="ktClose"><i class="fa-solid fa-arrow-left"></i></button>
          <div class="kt-title">Location Tracking</div>
          <div style="display:flex;gap:6px"><button type="button" class="kt-cbtn kt-or" id="ktCopy"><i class="fa-regular fa-copy"></i></button><button type="button" class="kt-cbtn kt-or" id="ktShot"><i class="fa-solid fa-image"></i></button></div>
        </div>
      </div>
      <div class="kt-body">
        <div class="kt-grab"></div>
        <div class="kt-row" style="align-items:flex-start">
          <div style="min-width:0"><div class="kt-lab" id="ktCour">Tracking Id:</div><div id="ktId" style="font-size:20px;font-weight:800;font-family:monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">-</div></div>
          <div style="text-align:right;flex-shrink:0"><div class="kt-lab">Status</div><span class="kt-pill" id="ktStatus">Transit</span></div>
        </div>
        <div class="kt-steps"><span class="kt-dot" id="ktD1"><i class="fa-solid fa-check"></i></span><span class="kt-line" id="ktL1"></span><span class="kt-dot" id="ktD2"><i class="fa-solid fa-check"></i></span><span class="kt-line" id="ktL2"></span><span class="kt-dot" id="ktD3"><i class="fa-solid fa-check"></i></span></div>
        <div class="kt-dates"><div><div class="kt-lab" id="ktCreated">Created</div><div class="kt-val">တရုတ်</div></div><div style="text-align:center"><div class="kt-lab">Transit Hub</div><div class="kt-val kt-or">လားရှိုး</div></div><div style="text-align:right"><div class="kt-lab" id="ktDestLab">Destination</div><div class="kt-val" id="ktDest">ရန်ကုန်</div></div></div>
        <div class="kt-info">
          <div class="kt-grid">
            <div style="grid-column:1/3"><div class="kt-lab">ပစ္စည်း (Item)</div><div class="kt-val" id="ktName" style="white-space:normal">-</div></div>
            <div><div class="kt-lab">Customer</div><div class="kt-val" id="ktCust">-</div></div>
            <div><div class="kt-lab">မှာတဲ့နေရာ</div><div class="kt-val" id="ktSrc">-</div></div>
            <div><div class="kt-lab">Order Cost</div><div class="kt-val kt-or" id="ktCost">0 Ks</div></div>
            <div><div class="kt-lab">တန်ဆာခ</div><div class="kt-val kt-or" id="ktFee">0 Ks</div></div>
            <div><div class="kt-lab">Quantity</div><div class="kt-val" id="ktQty">1</div></div>
            <div><div class="kt-lab">Weight</div><div class="kt-val" id="ktKg">0 Kg</div></div>
          </div>
          <div class="kt-vstage"><div id="ktBig"></div><span id="ktBigLbl" class="kt-or" style="font-size:10px;font-weight:800;margin-top:2px"></span></div>
        </div>
        <div class="kt-courier">
          <div style="display:flex;align-items:center;gap:10px;min-width:0"><div class="kt-av" id="ktAv"></div><div style="min-width:0"><div class="kt-val" id="ktCName">Courier</div><div class="kt-lab" id="ktCRole">Courier</div></div></div>
          <div style="display:flex;gap:7px"><button type="button" class="kt-rb" style="background:linear-gradient(135deg,#f26419,#c4420a);color:#fff" id="kt17"><i class="fa-solid fa-magnifying-glass-location"></i></button><button type="button" class="kt-rb" style="background:#fff;color:#0a0a0c" id="ktKd"><i class="fa-solid fa-globe"></i></button></div>
        </div>
        <div class="kt-edit"><input id="ktInput" placeholder="Tracking ID ထည့်/ပြင်ရန်..."><button type="button" id="ktSave">သိမ်း</button></div>
      </div>
    </div>`;
    document.body.appendChild(w);
    $('ktClose').onclick = closeTrack;
    $('ktCopy').onclick = () => { if (!cur.text) return toast('Tracking ID မရှိသေးပါ'); try { copyTextToClipboard(cur.text); } catch (e) { toast(cur.text); } };
    $('ktSave').onclick = saveId;
    $('kt17').onclick = () => ext('17track');
    $('ktKd').onclick = () => ext('kuaidi');
    $('ktShot').onclick = shot;
    return w;
  }
  function closeTrack() { const w = $('ktSheetWrap'); if (w) w.classList.add('kt-hidden'); cancelAnimationFrame(cur.raf); }
  function ext(p) {
    const id = trackId($('ktInput').value) || cur.text;
    if (!id) return toast('Tracking ID အရင်ထည့်ပါ');
    window.open(p === 'kuaidi' ? 'https://m.kuaidi100.com/result.jsp?nu=' + encodeURIComponent(id) : 'https://t.17track.net/en#nums=' + encodeURIComponent(id), '_blank', 'noopener');
  }
  function saveId() {
    const f = findItem(cur.id); if (!f) return;
    f.item.note = $('ktInput').value.trim();
    try { saveToLocalStorage(); renderAll(); if (f.gate && typeof renderGateDetail === 'function') renderGateDetail(); } catch (e) {}
    render(); toast('✅ Tracking ID သိမ်းဆည်းပြီးပါပြီ');
  }
  function shot() {
    const el = $('ktSheet'); if (!el || typeof html2canvas !== 'function') return toast('html2canvas မရှိပါ');
    toast('ပုံထုတ်နေပါသည်...');
    const ms = el.style.maxHeight, ov = el.style.overflow; el.style.maxHeight = 'none'; el.style.overflow = 'visible';
    html2canvas(el, { scale: 2, backgroundColor: '#0a0a0c', useCORS: true }).then(c => {
      el.style.maxHeight = ms; el.style.overflow = ov;
      const a = document.createElement('a'); a.href = c.toDataURL('image/png'); a.download = 'KISMET_Track_' + Date.now() + '.png'; a.click();
    }).catch(() => { el.style.maxHeight = ms; el.style.overflow = ov; toast('⚠️ ပုံထုတ်မရပါ'); });
  }

  function render() {
    const f = findItem(cur.id); if (!f) return;
    const it = f.item, gate = f.gate, m = BIG[it.method] ? it.method : 'Air';
    const stage = gate && gate.checked ? 4 : gate ? 3 : it.arrived ? 2 : 1;
    const pill = ['', 'တရုတ်မှ ထွက်ခွာ', 'လားရှိုးရောက်', 'ကားဂိတ်တင်ပြီး', 'ရန်ကုန်ရောက်'][stage];
    $('ktStatus').textContent = pill;
    const dest = gate ? gate.gate : 'ရန်ကုန်';
    $('ktDest').textContent = dest; $('ktDestLab').textContent = gate ? 'ကားဂိတ်' : 'Destination';
    const ts = (String(it.id).match(/(\d{13})/) || [])[1];
    $('ktCreated').textContent = ts ? 'Created, ' + fmtDate(+ts) : 'Created';
    $('ktD1').className = 'kt-dot done';
    $('ktD2').className = 'kt-dot ' + (stage >= 2 ? 'done' : 'act'); $('ktL1').className = 'kt-line' + (stage >= 2 ? ' done' : '');
    $('ktD3').className = 'kt-dot ' + (stage === 4 ? 'done' : stage >= 2 ? 'act' : ''); $('ktL2').className = 'kt-line' + (stage === 4 ? ' done' : '');
    const ex = trackId(it.note); cur.text = ex || (it.note ? String(it.note).trim() : '');
    $('ktCour').textContent = ex ? courier(ex) : 'Tracking Id:';
    $('ktId').textContent = cur.text || 'ID မထည့်ရသေးပါ';
    $('ktInput').value = it.note || '';
    $('ktName').textContent = it.name || 'ပစ္စည်း';
    $('ktCust').textContent = it.buyer || '-'; $('ktSrc').textContent = it.source || '-';
    const q = parseInt(it.qty) || 1, pr = parseFloat(it.price) || 0, fee = parseFloat(it.fee) || 0;
    $('ktCost').textContent = (pr > 0 ? Math.round(pr * q) : 0).toLocaleString() + ' Ks';
    $('ktFee').textContent = Math.round(fee).toLocaleString() + ' Ks';
    $('ktQty').textContent = q + ' ခု'; $('ktKg').textContent = (parseFloat(it.kg) || 0) + ' Kg';
    $('ktBig').innerHTML = BIG[m]; $('ktBigLbl').textContent = LBL[m];
    $('ktAv').innerHTML = MINI[m]; $('ktCName').textContent = ex ? courier(ex) : (it.source || 'China') + ' • ' + m;
    $('ktCRole').textContent = LBL[m] + ' • ' + pill;
    $('ktMarkEmo').textContent = EMO[m];
    animateMap(stage);
  }

  function animateMap(stage) {
    const act = $('ktAct'), mark = $('ktMark'); if (!act || !act.getTotalLength) return;
    const len = act.getTotalLength(), lsh = $('ktLsh'), lx = +lsh.getAttribute('cx'), ly = +lsh.getAttribute('cy');
    let lL = 0, best = 1e9; for (let l = 0; l <= len; l += 2) { const p = act.getPointAtLength(l), d = Math.hypot(p.x - lx, p.y - ly); if (d < best) { best = d; lL = l; } }
    const target = [0, lL * 0.5, lL, lL + (len - lL) * 0.62, len][stage];
    act.style.transition = 'none'; act.style.strokeDasharray = len + ' ' + len;
    cancelAnimationFrame(cur.raf);
    const t0 = performance.now(), dur = 1700;
    const step = (now) => {
      const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3), l = target * e, p = act.getPointAtLength(l);
      act.style.strokeDashoffset = String(len - l);
      mark.setAttribute('transform', 'translate(' + p.x.toFixed(1) + ',' + p.y.toFixed(1) + ')');
      if (k < 1) cur.raf = requestAnimationFrame(step);
    };
    cur.raf = requestAnimationFrame(step);
  }

  window.openKismetTrackModal = function (itemId) {
    const f = findItem(itemId); if (!f) return toast('ပစ္စည်း မတွေ့ပါ');
    cur.id = itemId; haptic();
    const w = $('ktSheetWrap') || buildSheet();
    w.classList.remove('kt-hidden'); render();
  };
  window.closeKismetTrackModal = closeTrack;

  /* ---------- 6. Tap an item card => open tracking ---------- */
  const HOSTS = '#orderListContainer,#lashioCheckList,#kgCalculatorItemList,#gateDetailModal';
  document.addEventListener('click', (e) => {
    try {
      if (e.target.closest('button,input,select,textarea,a,label,#ktSheetWrap')) return;
      const host = e.target.closest(HOSTS); if (!host) return;
      let el = e.target;
      while (el && el !== host) {
        const ids = new Set((el.innerHTML || '').match(/ORD-[A-Za-z0-9-]+/g) || []);
        if (ids.size > 1) return;
        if (ids.size === 1) { window.openKismetTrackModal([...ids][0]); return; }
        el = el.parentElement;
      }
    } catch (err) {}
  }, false);

  /* ---------- 7. Kg & % : no ring animation (static, instant) ---------- */
  window.KISMET_ANIMATE_DONUT = function () {};

  placePanel();
})();
