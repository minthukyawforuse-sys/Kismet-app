/* KISMET — gate / group payment E-Voucher ("ဘယ်သူ ဘယ်လောက်") + save to Gallery */
(function () {
  if (window.__gvLoaded) return; window.__gvLoaded = true;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toast = (m) => { try { if (typeof showToast === 'function') showToast(m); } catch (e) {} };
  const num = (v) => parseFloat(v) || 0;
  const fmt = (n) => Math.round(n).toLocaleString();
  const NONAME = '(နာမည်မရှိ)';
  const GL = { Air: 'လေယာဉ်', Land: 'ကားဂိတ်', Post: 'စာတိုက်' };
  const GE = { Air: '✈️', Land: '🚚', Post: '📮' };
  const buyerOf = (i) => (i.buyer || '').trim() || NONAME;
  const gates = () => { try { return gateShipments; } catch (e) { return []; } };
  const gateById = (id) => gates().find(g => g.id === id);
  const gateOfItem = (id) => gates().find(g => (g.items || []).some(i => i.id === id));
  const today = () => { try { return localDateStr(); } catch (e) { return new Date().toISOString().slice(0, 10); } };

  function group(list) {
    const m = new Map();
    list.forEach(i => { const k = buyerOf(i); if (!m.has(k)) m.set(k, { name: k, items: [], kg: 0, cl: 0, ly: 0 }); const g = m.get(k); g.items.push(i); g.kg += num(i.kg); g.cl += num(i.fee); g.ly += num(i.gateFee); });
    return [...m.values()].sort((a, b) => (b.cl + b.ly) - (a.cl + a.ly) || b.kg - a.kg);
  }

  /* ---- shared white voucher renderer ---- */
  const TH = 'padding:5px 2px;font-size:9.5px;color:#64748b;font-weight:700;border-bottom:1px solid #cbd5e1;';
  const TD = 'padding:6px 2px;border-bottom:1px solid #f1f5f9;vertical-align:top;';
  function paint(v) {
    const area = $('eVoucherContentArea'), modal = $('eVoucherModal'); if (!area || !modal) return false;
    area.style.lineHeight = '1.7';
    const cols = v.cols; // [{h, align, w}]
    const head = cols.map(c => `<th style="${TH}text-align:${c.a};${c.w ? 'width:' + c.w + ';' : ''}">${c.h}</th>`).join('');
    const body = v.rows.map(r => `<tr>${r.map((cell, i) => `<td style="${TD}text-align:${cols[i].a};${cols[i].b ? 'font-weight:800;color:#0f172a;' : 'color:#334155;font-weight:600;'}">${cell}</td>`).join('')}</tr>`).join('');
    const tot = v.totalRow ? `<tr>${v.totalRow.map((cell, i) => `<td style="padding:7px 2px;text-align:${cols[i].a};font-weight:900;color:#0f172a;border-top:2px solid #0f172a;">${cell}</td>`).join('')}</tr>` : '';
    area.innerHTML = `
      <div style="text-align:center;border-bottom:2px dashed #cbd5e1;padding:6px 0 12px;">
        <div style="font-size:22px;font-weight:900;letter-spacing:.2em;color:#0f172a;">KISMET</div>
        <div style="font-size:10px;color:#64748b;margin-top:5px;font-weight:600;">${esc(v.title)} • ${esc(v.date || today())}</div>
      </div>
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:10px 12px;margin-top:12px;font-size:11px;line-height:1.9;">
        ${v.meta.map(([k, val, hl]) => `<div style="display:flex;justify-content:space-between;gap:10px;"><span style="color:#64748b;">${esc(k)}</span><strong style="color:${hl ? '#ea580c' : '#0f172a'};text-align:right;">${val}</strong></div>`).join('')}
      </div>
      <table style="width:100%;border-collapse:collapse;margin-top:12px;font-size:10.5px;"><thead><tr>${head}</tr></thead><tbody>${body}${tot}</tbody></table>
      <div style="margin-top:12px;border-radius:12px;background:#fff7ed;border:1px solid #fed7aa;padding:10px 12px;display:flex;justify-content:space-between;align-items:center;">
        <span style="font-size:11px;font-weight:800;color:#9a3412;flex:1;min-width:0;padding-right:8px;">${esc(v.payLabel || 'စုစုပေါင်း ပေးရမည့်ငွေ')}</span><span style="font-size:17px;font-weight:900;color:#ea580c;white-space:nowrap;flex-shrink:0;">${fmt(v.pay)} Ks</span>
      </div>
      ${v.note ? `<div style="margin-top:8px;font-size:10px;color:#b45309;text-align:center;">${esc(v.note)}</div>` : ''}
      <div style="text-align:center;font-size:10px;color:#94a3b8;margin-top:12px;">ဝယ်ယူအားပေးမှုကို အထူးကျေးဇူးတင်ရှိပါသည် 🙏</div>`;
    modal.classList.remove('hidden'); return true;
  }
  function saveSoon() { setTimeout(() => { try { downloadEVoucherImage(); } catch (e) { toast('⚠️ ပုံထုတ်မရပါ'); } }, 350); }

  /* ---- 1) Gate voucher : every customer's payable ---- */
  window.gvGate = function (gid, save) {
    const g = gateById(gid); if (!g) return toast('ဂိတ်စာရင်း မတွေ့ပါ');
    const items = g.items || [], groups = group(items), kg = items.reduce((a, i) => a + num(i.kg), 0);
    const fr = num(g.freight), cl = groups.reduce((a, x) => a + x.cl, 0), ly = groups.reduce((a, x) => a + x.ly, 0), tr = g.transport || 'Land';
    const rows = groups.map(x => [`${esc(x.name)}<div style="font-size:9px;color:#94a3b8;font-weight:600;">${x.items.length} order</div>`, `${x.kg.toFixed(2)}<div style="font-size:9px;color:#94a3b8;">${(kg > 0 ? x.kg / kg * 100 : 100 / groups.length).toFixed(1)}%</div>`, x.cl > 0 ? fmt(x.cl) : '-', fr > 0 ? fmt(x.ly) : '-', fmt(x.cl + x.ly)]);
    paint({
      title: `${GL[tr]} ပို့ဆောင်ခ ဘောင်ချာ`, date: g.date,
      meta: [['ဂိတ် / အမည်', `${GE[tr]} ${esc(g.gate)}`], ['လမ်းကြောင်း', 'လားရှိုး → ရန်ကုန်'], ['ပစ္စည်း / Customer', `${items.length} မျိုး • ${groups.length} ဦး`], ['စုစုပေါင်း Kg', `${kg.toFixed(2)} Kg`],
        ['လားရှိုး → ရန်ကုန် တန်ဆာခ', fr > 0 ? `${fmt(fr)} Ks` : 'မထည့်ရသေးပါ', true], ...(fr > 0 && kg > 0 ? [['Kg တစ်ခုလျှင်', `≈ ${fmt(fr / kg)} Ks`]] : [])],
      cols: [{ h: 'Customer', a: 'left', b: true }, { h: 'Kg', a: 'right', w: '15%' }, { h: 'တရုတ်→<br>လားရှိုး', a: 'right', w: '19%' }, { h: 'လားရှိုး→<br>ရန်ကုန်', a: 'right', w: '19%' }, { h: 'ပေးရမည်', a: 'right', w: '19%', b: true }],
      rows, totalRow: ['စုစုပေါင်း', kg.toFixed(2), cl > 0 ? fmt(cl) : '-', fr > 0 ? fmt(ly) : '-', fmt(cl + ly)], pay: cl + ly,
      note: fr > 0 ? '' : 'လားရှိုး → ရန်ကုန် တန်ဆာခ မထည့်ရသေးပါ — ထည့်ပြီးမှ ဘောင်ချာ ပြန်ထုတ်ပါ'
    });
    if (save) saveSoon();
  };

  /* ---- 2) One customer's voucher (also replaces the older Lashio → Yangon one) ---- */
  window.gvGroup = function (list, name, gate, save) {
    if (!list || !list.length) return;
    const g = gate || gateOfItem(list[0].id) || null, kg = list.reduce((a, i) => a + num(i.kg), 0);
    const cl = list.reduce((a, i) => a + num(i.fee), 0), ly = list.reduce((a, i) => a + num(i.gateFee), 0), hasLY = !!g && num(g.freight) > 0;
    const tr = g ? (g.transport || 'Land') : null;
    const cols = [{ h: 'ပစ္စည်း', a: 'left', b: true }, { h: 'Qty', a: 'center', w: '9%' }, { h: 'Kg', a: 'right', w: '13%' }, { h: 'တရုတ်→<br>လားရှိုး', a: 'right', w: '19%' }, ...(g ? [{ h: 'လားရှိုး→<br>ရန်ကုန်', a: 'right', w: '19%' }] : [])];
    const rows = list.map(i => [esc(i.name), esc(i.qty || 1), num(i.kg).toFixed(2), num(i.fee) > 0 ? fmt(num(i.fee)) : '-', ...(g ? [hasLY ? fmt(num(i.gateFee)) : '-'] : [])]);
    paint({
      title: 'တန်ဆာခ ဘောင်ချာ', date: g ? g.date : undefined,
      meta: [['Customer / Group', esc(name)], ...(g ? [['ဂိတ်', `${GE[tr]} ${esc(g.gate)}`]] : [['အခြေအနေ', 'လားရှိုးရောက် (ဂိတ်မတင်ရသေး)']]), ['စုစုပေါင်း Kg', `${kg.toFixed(2)} Kg`],
        ['တရုတ် → လားရှိုး (Kg ခ)', cl > 0 ? `${fmt(cl)} Ks` : '-'], ...(g ? [['လားရှိုး → ရန်ကုန် (တန်ဆာ)', hasLY ? `${fmt(ly)} Ks` : 'မထည့်ရသေးပါ']] : [])],
      cols, rows, totalRow: ['စုစုပေါင်း', '', kg.toFixed(2), cl > 0 ? fmt(cl) : '-', ...(g ? [hasLY ? fmt(ly) : '-'] : [])], pay: cl + ly,
      note: g && !hasLY ? 'လားရှိုး → ရန်ကုန် တန်ဆာခ မထည့်ရသေးပါ — ထည့်ပြီးမှ ပြန်ထုတ်ပါ' : ''
    });
    if (save) saveSoon();
  };
  window.klVoucherLY = function (list, name, gateName) {
    const g = gateName ? gates().find(x => x.gate === gateName) : null;
    window.gvGroup(list, name, g);
  };

  /* ---- 3) One order's voucher (used by the tracking sheet's image button) ---- */
  window.gvItem = function (id, save) {
    let it = null, g = null;
    try { it = Object.values(allRouteRecords).reduce((a, l) => a.concat(Array.isArray(l) ? l : []), []).find(i => i && i.id === id); } catch (e) {}
    g = gateOfItem(id); if (!it && g) it = g.items.find(i => i.id === id);
    if (!it) return toast('ပစ္စည်း မတွေ့ပါ');
    const q = Math.max(1, parseInt(it.qty) || 1), kg = num(it.kg), order = num(it.price) * q, cl = num(it.fee), hasLY = !!g && num(g.freight) > 0, ly = hasLY ? num(it.gateFee) : 0;
    const ts = (String(id).match(/(\d{13})/) || [])[1], created = ts ? new Date(+ts).toISOString().slice(0, 10) : undefined, tr = g ? (g.transport || 'Land') : null;
    const rows = [['Quantity', `${q} ခု`], ['Weight', `${kg} Kg`]];
    if (order > 0) rows.push(['Order Cost (ပစ္စည်းဈေး)', `${fmt(order)} Ks`]);
    rows.push(['တန်ဆာခ (တရုတ် → လားရှိုး)', cl > 0 ? `${fmt(cl)} Ks` : '-']);
    if (g) rows.push(['တန်ဆာခ (လားရှိုး → ရန်ကုန်)', hasLY ? `${fmt(ly)} Ks` : 'မထည့်ရသေးပါ']);
    paint({
      title: 'ပစ္စည်း တန်ဆာခ ဘောင်ချာ', date: g ? g.date : created,
      meta: [['Customer', esc((it.buyer || '').trim() || NONAME)], ['ပစ္စည်း', esc(it.name)], ...(it.note ? [['Tracking / မှတ်ချက်', esc(it.note)]] : []), ...(g ? [['ဂိတ်', `${GE[tr]} ${esc(g.gate)}`]] : []), ['လမ်းကြောင်း', g ? 'တရုတ် → လားရှိုး → ရန်ကုန်' : 'တရုတ် → လားရှိုး']],
      cols: [{ h: 'အကြောင်းအရာ', a: 'left', b: true }, { h: 'ပမာဏ', a: 'right', b: true }],
      rows, totalRow: ['တန်ဆာခ စုစုပေါင်း', `${fmt(cl + ly)} Ks`], pay: order + cl + ly,
      payLabel: order > 0 ? 'စုစုပေါင်း (ပစ္စည်းဈေး + တန်ဆာခ)' : 'စုစုပေါင်း တန်ဆာခ',
      note: g && !hasLY ? 'လားရှိုး → ရန်ကုန် တန်ဆာခ မထည့်ရသေးပါ — ထည့်ပြီးမှ ပြန်ထုတ်ပါ' : ''
    });
    if (save) saveSoon();
  };
  window.gvSaveGate = (gid) => window.gvGate(gid, true);
})();
