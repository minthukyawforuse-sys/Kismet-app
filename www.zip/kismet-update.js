/* KISMET — in-app update from GitHub (commit-pinned jsDelivr bundle) */
(function () {
  if (window.__kuLoaded) return; window.__kuLoaded = true;
  const $ = (id) => document.getElementById(id);
  const LOCAL = window.KISMET_VERSION || '0';
  const K_REPO = 'kismet_update_repo', K_BASE = 'kismet_remote_base', K_VER = 'kismet_remote_version';
  const ls = {
    get: (k) => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } },
    set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} },
    del: (k) => { try { localStorage.removeItem(k); } catch (e) {} }
  };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const cmp = (a, b) => {
    const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; }
    return 0;
  };
  const parseRepo = (s) => {
    const m = String(s || '').trim().replace(/^https?:\/\/github\.com\//, '').replace(/\.git$/, '').replace(/\/+$/, '').match(/^([\w.-]+)\/([\w.-]+)(?:[#@:]([\w./-]+))?$/);
    return m ? { owner: m[1], repo: m[2], branch: m[3] || 'main' } : null;
  };

  async function latest(r) {
    const c = await fetch(`https://api.github.com/repos/${r.owner}/${r.repo}/commits/${encodeURIComponent(r.branch)}`, { headers: { Accept: 'application/vnd.github+json' }, cache: 'no-store' });
    if (!c.ok) throw new Error(c.status === 404 ? 'GitHub repo မတွေ့ပါ (private ဖြစ်နိုင်သည်)' : 'GitHub ချိတ်မရပါ (' + c.status + ')');
    const sha = (await c.json()).sha, base = `https://cdn.jsdelivr.net/gh/${r.owner}/${r.repo}@${sha}/`;
    const v = await fetch(base + 'version.json', { cache: 'no-store' });
    if (!v.ok) throw new Error('version.json မတွေ့ပါ');
    const info = await v.json();
    return { sha, base, version: String(info.version || '0'), notes: info.notes || '' };
  }

  async function applyBase(base, ver) {
    const res = await fetch(base + 'index.html', { cache: 'no-store' });
    if (!res.ok) throw new Error('index.html ဒေါင်းမရပါ');
    let html = await res.text();
    if (html.indexOf('<head>') < 0) throw new Error('index.html မမှန်ပါ');
    ls.set(K_BASE, base); ls.set(K_VER, ver);
    window.__kRemote = true;
    html = html.replace('<head>', `<head><base href="${base}">`);
    document.open(); document.write(html); document.close();
  }

  function sheet() {
    let w = $('kuSheet');
    if (!w) {
      w = document.createElement('div'); w.id = 'kuSheet'; w.className = 'ly-ov ly-off';
      w.addEventListener('click', (e) => { if (e.target === w) w.classList.add('ly-off'); });
      document.body.appendChild(w);
    }
    return w;
  }

  window.openKismetUpdate = function () {
    const cur = ls.get(K_VER) || LOCAL, w = sheet();
    w.innerHTML = `<div class="ly-sh"><div class="ly-sh-t"><i class="fa-solid fa-cloud-arrow-down"></i>&nbsp; App Update</div>
      <p class="ly-hint">လက်ရှိ Version: <b style="color:#fb923c">${esc(cur)}</b>${ls.get(K_BASE) ? ' (GitHub မှ update ထားသည်)' : ' (ပါလာသည့် version)'}</p>
      <label class="ly-f"><span>GitHub Repo (owner/repo — branch ထည့်လိုလျှင် owner/repo@main)</span><input id="kuRepo" value="${esc(ls.get(K_REPO))}" placeholder="owner/repo" autocapitalize="off" autocomplete="off"></label>
      <div id="kuMsg" class="ly-rate" style="text-align:left"></div>
      <div class="ly-btns"><button type="button" class="ly-b0" id="kuClose">ပိတ်မည်</button><button type="button" class="ly-b1" id="kuCheck">Update စစ်မည်</button></div>
      ${ls.get(K_BASE) ? '<button type="button" class="ly-b0" id="kuReset" style="width:100%;margin-top:8px;padding:11px;border-radius:13px;border:0;font-weight:700">ပါလာသည့် version သို့ ပြန်သွားမည်</button>' : ''}</div>`;
    w.classList.remove('ly-off');
    const msg = (t, c) => { const m = $('kuMsg'); m.style.color = c || '#8a8a92'; m.innerHTML = t; };
    $('kuClose').onclick = () => w.classList.add('ly-off');
    if ($('kuReset')) $('kuReset').onclick = () => { ls.del(K_BASE); ls.del(K_VER); location.reload(); };
    $('kuCheck').onclick = async () => {
      const r = parseRepo($('kuRepo').value);
      if (!r) return msg('Repo ပုံစံမှား — owner/repo ဟု ရိုက်ပါ', '#ef6b6b');
      ls.set(K_REPO, $('kuRepo').value.trim()); msg('စစ်နေသည်…');
      try {
        const L = await latest(r);
        if (cmp(L.version, cur) <= 0) return msg(`✅ နောက်ဆုံး version ဖြစ်ပါသည် (${esc(cur)})`, '#7fcf8e');
        msg(`🆕 Version <b>${esc(L.version)}</b> ရှိပါပြီ${L.notes ? '<br>' + esc(L.notes) : ''}`, '#fb923c');
        const b = $('kuCheck'); b.textContent = 'Update တင်မည်';
        b.onclick = async () => {
          b.disabled = true; msg('ဒေါင်းလုဒ်လုပ်နေသည်…');
          try { await applyBase(L.base, L.version); } catch (e) { b.disabled = false; msg('❌ ' + esc(e.message), '#ef6b6b'); }
        };
      } catch (e) { msg('❌ ' + esc(e.message || 'Network error'), '#ef6b6b'); }
    };
  };

  function addButton() {
    if ($('kuBtn')) return true;
    const bell = document.querySelector('[onclick^="openNotiCenterModal"]'); if (!bell || !bell.parentNode) return false;
    const b = document.createElement('button'); b.id = 'kuBtn'; b.type = 'button'; b.title = 'App Update';
    b.className = bell.className.replace(/\brelative\b/g, '');
    b.innerHTML = '<i class="fa-solid fa-cloud-arrow-down"></i><span id="kuDot" class="hidden" style="position:absolute;top:-2px;right:-2px;width:9px;height:9px;border-radius:99px;background:#f26419"></span>';
    b.style.position = 'relative'; b.onclick = window.openKismetUpdate;
    bell.parentNode.insertBefore(b, bell); return true;
  }
  const iv = setInterval(() => { if (addButton()) clearInterval(iv); }, 500);

  setTimeout(async () => {
    const r = parseRepo(ls.get(K_REPO)); if (!r || !navigator.onLine) return;
    try { const L = await latest(r); if (cmp(L.version, ls.get(K_VER) || LOCAL) > 0 && $('kuDot')) $('kuDot').classList.remove('hidden'); } catch (e) {}
  }, 4000);
})();
